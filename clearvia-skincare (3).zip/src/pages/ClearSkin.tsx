import React from 'react';
import { Button } from '../components/Button';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { Star } from 'lucide-react';

export function ClearSkin() {
  const navigate = useNavigate();
  const { addToCart } = useCart();

  const handleBuyNow = (productId: string) => {
    addToCart(productId);
    navigate('/checkout');
  };

  return (
    <div className="pt-24 min-h-screen bg-gray-50 flex flex-col justify-center py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="bg-teal-500 rounded-[3rem] p-12 md:p-24 text-center text-white relative overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 -mr-20 -mt-20 w-80 h-80 bg-teal-400 rounded-full blur-3xl opacity-50" />
          <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 bg-teal-400 rounded-full blur-3xl opacity-50" />
          
          <div className="relative z-10">
            <h2 className="text-4xl md:text-7xl font-bold tracking-tighter mb-8 max-w-4xl mx-auto leading-tight">
              Ready for your <br />
              <span className="text-teal-100">Clearest Skin Ever?</span>
            </h2>
            <p className="text-white/90 text-lg md:text-2xl mb-8 max-w-2xl mx-auto font-medium">
              Grab the Essential Trio combo at just ₹999. Valid until stocks last.
            </p>
            
            <div className="flex justify-center items-center gap-1 mb-10">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-current text-yellow-300" />
              ))}
              <span className="ml-2 text-white/90 font-bold text-sm">4.9/5 from 10,000+ users</span>
            </div>

            <Button size="xl" className="w-full sm:w-auto bg-white text-teal-600 hover:bg-gray-100 px-12 text-lg shadow-xl" onClick={() => handleBuyNow('combo')}>
              Claim Your Offer Now
            </Button>
            <p className="mt-8 text-sm font-bold tracking-widest uppercase text-white/80">Free Shipping across India · Cash on Delivery available</p>
          </div>
        </div>
      </div>
    </div>
  );
}
