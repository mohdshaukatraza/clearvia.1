import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { BackButton } from '../components/BackButton';

export function FAQ() {
  const faqs = [
    {
      question: "What is included in the ₹999 combo?",
      answer: "The Essential Trio includes our Deep Cleansing Face Wash (100ml), Acne-Defense Serum (30ml), and Ultra-Matte Sunscreen (50ml). This is enough for a 45-60 day routine."
    },
    {
      question: "How long until I see results?",
      answer: "Most users report visible reduction in active acne within 7-10 days. For oil control, results are immediate. For dark spots, it usually takes 3-4 weeks of consistent usage."
    },
    {
      question: "What is your delivery time?",
      answer: "We ship from Bangalore and Delhi. Deliveries take 3-5 working days within major cities in India, and 5-7 days for other regions."
    },
    {
      question: "Do you offer Cash on Delivery (COD)?",
      answer: "Yes, we offer COD across most pincodes in India. You can select it at the checkout page."
    },
    {
      question: "What is your return/replacement policy?",
      answer: "We offer replacements for damaged or incorrect items reported within 48 hours of delivery. For hygiene reasons, personal care products cannot be returned once the seal is broken. Please check our Policy page for full details."
    },
    {
      question: "Why should I trust a new brand like Clearvia?",
      answer: "We may be new, but our commitment to quality is extreme. By skipping big marketing budgets, we focus all our resources on pure ingredients and effective formulas. Every order supports a young Indian startup dedicated to better skincare."
    },
    {
      question: "Is this combo suitable for sensitive skin?",
      answer: "Yes, our formulas are crafted with gentle but effective ingredients suitable for sensitive, acne-prone skin. As with any new product, we recommend a patch test before full application."
    }
  ];

  return (
    <div className="bg-white min-h-screen py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <BackButton />
        <div className="text-center mb-20">
          <h1 className="text-5xl font-bold tracking-tighter text-black mb-6 italic">Support & FAQ.</h1>
          <p className="text-gray-500 text-lg">Everything you need to know about Clearvia.</p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <FAQItem key={index} question={faq.question} answer={faq.answer} />
          ))}
        </div>
        
        <div className="mt-24 p-12 bg-gray-50 text-center rounded-[2rem]">
          <h3 className="text-xl font-bold text-black mb-4 uppercase tracking-widest">Still have questions?</h3>
          <p className="text-gray-500 mb-8 max-w-sm mx-auto">Skip the email, chat with us directly for instant help.</p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <a 
              href="https://wa.me/message/3MPLW7S7QCJWC1" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-black font-extrabold flex items-center gap-2 px-6 py-3 bg-white border border-gray-100 rounded-full hover:shadow-lg transition-all"
            >
              <span>WhatsApp Us</span>
            </a>
            <a 
              href="tel:+919717023665" 
              className="text-black font-extrabold flex items-center gap-2 px-6 py-3 bg-white border border-gray-100 rounded-full hover:shadow-lg transition-all"
            >
              <span>Call: 9717023665</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

function FAQItem({ question, answer }: { question: string, answer: string }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className={cn(
      "border border-gray-100 p-6 md:p-8 transition-all duration-300",
      isOpen ? "bg-gray-50 border-teal-200" : "bg-white"
    )}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center text-left"
      >
        <span className="text-base font-bold text-black uppercase tracking-wide leading-relaxed pr-8">{question}</span>
        {isOpen ? <ChevronUp className="w-5 h-5 flex-shrink-0" /> : <ChevronDown className="w-5 h-5 flex-shrink-0" />}
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <p className="pt-6 text-gray-500 text-sm leading-relaxed italic">{answer}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
