import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Star, Check, Plus, Minus, Shield, Sparkles, Droplets, Sun, Info, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../components/Button';
import { useCart } from '../context/CartContext';
import { productsData } from '../data/products';
import { cn } from '../lib/utils';
import { BackButton } from '../components/BackButton';

export function ProductDetail() {
  const { id } = useParams();
  const productId = id && productsData[id] ? id : 'combo';
  const product = productsData[productId];

  const [selectedImage, setSelectedImage] = useState(product.images[0]);
  const [activeTab, setActiveTab] = useState<'benefits' | 'ingredients' | 'howtouse'>('benefits');
  const [quantity, setQuantity] = useState(1);
  const [visibleReviews, setVisibleReviews] = useState(2);
  const { addToCart } = useCart();
  const navigate = useNavigate();

  const reviewsData = [
    { name: "Manasi K.", text: "Since I've started the clear skin routine there's no redness on my skin and acne is totally in control. All red bumps are reducing and I can see visible results within just 2 weeks. Highly recommend this for oily skin.", title: "Life changing product!" },
    { name: "Surbhi M.", text: "I have tried so many serums but this one actually works without making my skin dry. The texture is so light. My acne scars are visibly fading.", title: "Best purchase for my skin" },
    { name: "Riya S.", text: "Very gentle on the skin. I have sensitive skin and it didn't irritate it at all. The glow is unreal!", title: "Gentle and effective" },
    { name: "Sneha P.", text: "I can see the difference in my skin texture. It feels much smoother and hydrated. Will definitely repurchase.", title: "Smooth and hydrated skin" },
    { name: "Aarohi J.", text: "This is my 3rd bottle and I just can't get enough of this amazing product. Worth every penny.", title: "My holy grail!" },
  ];

  // Reset selected image when product changes
  useEffect(() => {
    setSelectedImage(product.images[0]);
    setQuantity(1);
    setActiveTab('benefits');
  }, [productId]);

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(productId);
    }
    navigate('/checkout');
  };

  const tabs = [
    { id: 'benefits', label: 'What Makes It Potent?' },
    { id: 'ingredients', label: 'Ingredients' },
    { id: 'howtouse', label: 'How To Use' },
  ];

  return (
    <div className="bg-[#FAF9F6] min-h-screen pt-20 md:pt-24 pb-12 font-sans text-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 lg:max-w-[1400px]">
        <div className="mb-3 md:mb-6">
          <BackButton />
        </div>
        
        <div className="flex flex-col lg:flex-row gap-0 lg:gap-20 items-start">
          
          {/* Left Column: Images + Scrolling Details */}
          <div className="contents lg:flex lg:flex-col lg:w-[55%] xl:w-[60%] gap-12 lg:gap-16">
            
            {/* Image Gallery */}
            <div className="order-1 w-full lg:w-auto mb-6 lg:mb-0 flex flex-col-reverse md:flex-row gap-3 md:gap-6 lg:sticky lg:top-32 lg:h-[calc(100vh-10rem)]">
              <div className="flex md:flex-col gap-4 overflow-x-auto md:overflow-y-auto scrollbar-hide md:w-20 lg:w-24 shrink-0">
                {product.images.map((img: string, i: number) => (
                  <button 
                    key={i} 
                    onClick={() => setSelectedImage(img)}
                    className={cn(
                      "aspect-square bg-white border cursor-pointer hover:border-gray-800 transition-colors shrink-0 outline-none w-20 md:w-full",
                      selectedImage === img ? "border-gray-800" : "border-gray-200"
                    )}
                  >
                    <img src={img} alt={`Product view ${i + 1}`} className="w-full h-full object-cover mix-blend-multiply p-1" />
                  </button>
                ))}
              </div>
              <motion.div 
                 key={selectedImage}
                 initial={{ opacity: 0 }}
                 animate={{ opacity: 1 }}
                 className="flex-1 w-full bg-white border border-gray-100 flex items-center justify-center p-4 sm:p-8 lg:p-12 min-h-[400px] h-full"
              >
                <img 
                  src={selectedImage} 
                  alt={product.name} 
                  className="w-full h-full object-contain mix-blend-multiply"
                />
              </motion.div>
            </div>

            {/* Secondary Details Group */}
            <div className="order-3 w-full lg:w-auto flex flex-col gap-10 md:gap-16 mt-4 lg:mt-0">
            {/* Two Column Layout: Who is it for? & How to use? */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-8 md:pt-16 border-t border-gray-200 mt-2 md:mt-8">
              
              {/* Left Column: Who is it for? */}
              <div className="bg-gray-50 p-8 rounded-2xl relative">
                <h2 className="text-2xl font-light tracking-tight text-black mb-8">Who is it <span className="font-bold">for?</span></h2>
                
                <div className="space-y-6 relative z-10 w-full">
                  <div>
                    <div className="text-[#E36940] text-xs font-bold uppercase tracking-wider mb-1">Targets</div>
                    <p className="text-sm font-medium text-gray-800">Acne, Oily, Blackheads & Irritation</p>
                  </div>
                  <div>
                    <div className="text-[#E36940] text-xs font-bold uppercase tracking-wider mb-1">Skin Type</div>
                    <p className="text-sm font-medium text-gray-800">Combination/Oily Skin</p>
                  </div>
                  <div>
                    <div className="text-[#E36940] text-xs font-bold uppercase tracking-wider mb-1">Suitable For</div>
                    <p className="text-sm font-medium text-gray-800">18+ years of age</p>
                  </div>
                </div>
              </div>

              {/* Right Column: How to use? */}
              <div className="bg-gray-50 p-8 rounded-2xl relative">
                <h2 className="text-2xl font-light tracking-tight text-black mb-8">How to <span className="font-bold">use?</span></h2>
                
                <div className="space-y-6 relative z-10 w-full">
                  <div>
                    <div className="text-[#E36940] text-xs font-bold uppercase tracking-wider mb-1">Instructions</div>
                    <p className="text-sm font-medium text-gray-800 leading-relaxed">Apply 2-3 drops after cleansing & toning. Let the serum absorb fully into the skin before moving on to the next step of your routine.</p>
                  </div>
                  <div>
                    <div className="text-[#E36940] text-xs font-bold uppercase tracking-wider mb-1">When to use</div>
                    <p className="text-sm font-medium text-gray-800 leading-relaxed">PM. Start with every alternate day and after 2 weeks of usage, use it everyday.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Customer Review Section */}
            <div className="pt-16 pb-24 border-t border-gray-200 mt-16">
               <h2 className="text-3xl font-light tracking-tight mb-12 text-black">Customer <br/><span className="font-bold">Reviews</span></h2>
               
               {/* OVERALL RATING */}
               <div className="flex flex-col md:flex-row gap-8 items-start mb-12 bg-white p-6 md:p-8 border border-gray-100">
                 <div className="flex flex-col items-center justify-center shrink-0 w-full md:w-32">
                   <div className="text-5xl font-light text-gray-900 mb-2">4.9</div>
                   <div className="flex gap-1 mb-2">
                     {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-[#E36940] text-[#E36940]" />)}
                   </div>
                   <div className="text-xs text-gray-500 font-medium">Based on 128 Reviews</div>
                 </div>
                 
                 <div className="w-full flex-1 space-y-2">
                    {[
                      { stars: 5, pct: 92 },
                      { stars: 4, pct: 6 },
                      { stars: 3, pct: 2 },
                      { stars: 2, pct: 0 },
                      { stars: 1, pct: 0 },
                    ].map(row => (
                      <div key={row.stars} className="flex items-center gap-3">
                        <div className="w-12 text-xs font-medium text-gray-500 flex items-center gap-1">{row.stars} <Star className="w-3 h-3 fill-gray-400 text-gray-400" /></div>
                        <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full bg-gray-800" style={{ width: `${row.pct}%` }} />
                        </div>
                        <div className="w-8 text-xs text-gray-500 text-right">{row.pct}%</div>
                      </div>
                    ))}
                 </div>
               </div>

               {/* INDIVIDUAL REVIEWS */}
               <div className="space-y-8">
                 {reviewsData.slice(0, visibleReviews).map((review, idx) => (
                   <div key={idx} className="border-b border-gray-100 pb-8">
                     <div className="flex gap-1 mb-3">
                       {[...Array(5)].map((_, i) => <Star key={i} className="w-3 h-3 fill-gray-800 text-gray-800" />)}
                     </div>
                     <h4 className="text-sm font-bold text-gray-900 mb-2">{review.title}</h4>
                     <p className="text-sm text-gray-600 leading-relaxed mb-4">"{review.text}"</p>
                     <div className="flex items-center gap-3">
                       <span className="text-xs font-bold text-gray-800 bg-gray-100 px-2 py-1">{review.name}</span>
                       <span className="flex items-center gap-1 text-[10px] text-green-700 font-bold uppercase tracking-wider"><Check className="w-3 h-3" /> Verified Buyer</span>
                     </div>
                   </div>
                 ))}
                 
                 {visibleReviews < reviewsData.length && (
                   <Button 
                     variant="outline" 
                     className="w-full md:w-auto mt-4 px-8 border-gray-300 text-gray-700 hover:bg-gray-50"
                     onClick={() => setVisibleReviews(prev => prev + 2)}
                   >
                     Load More Reviews
                   </Button>
                 )}
               </div>
            </div>

            </div>

          </div>

          {/* Right Column: Sticky Product Info & Details */}
          <div className="order-2 w-full lg:w-[45%] xl:w-[40%] flex flex-col mb-10 lg:mb-0 lg:sticky lg:top-32 lg:h-[calc(100vh-8rem)] lg:overflow-y-auto pb-16 lg:pb-32 pr-4 custom-scrollbar">
            
            {/* Header / Titles */}
            <div className="mb-6">
              <h1 className="text-3xl md:text-4xl font-light text-gray-900 mb-2 leading-tight">{product.name}</h1>
              
              <div className="flex items-center gap-2 mb-6">
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-3.5 h-3.5 fill-gray-800 text-gray-800" />)}
                </div>
                <span className="text-xs text-gray-600 font-medium">4.9 Reviews</span>
              </div>
              
              <p className="text-sm text-gray-700 font-medium mb-3">{product.subtitle || 'Reduces Acne, Blackheads & Excessive Oil'}</p>
              <p className="text-sm text-gray-500 leading-relaxed mb-6">
                {product.description}
              </p>
              
              <div className="flex flex-wrap gap-4 text-xs text-gray-500 mb-6 border-b border-gray-200 pb-6">
                <span className="flex items-center gap-1"><Check className="w-3 h-3 text-gray-400" /> Fragrance Free</span>
                <span className="flex items-center gap-1"><Check className="w-3 h-3 text-gray-400" /> Non-comedogenic</span>
                <span className="flex items-center gap-1"><Check className="w-3 h-3 text-gray-400" /> Essential Oil Free</span>
              </div>
            </div>

            {/* Variants */}
            <div className="mb-8">
              <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Choose Variants</p>
              <div className="flex gap-3">
                 <button className="border border-gray-800 text-gray-900 text-xs py-2 px-6 font-medium bg-white">Standard</button>
                 {productId === 'combo' && (
                    <button className="border border-gray-200 text-gray-400 text-xs py-2 px-6 hover:border-gray-800 hover:text-gray-900 transition-colors bg-white">Mini Size</button>
                 )}
              </div>
            </div>

            {/* Price */}
            <div className="mb-8">
              <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Price</p>
              <div className="flex items-end gap-3 mb-1">
                <span className="text-3xl font-light text-gray-900 leading-none">₹{product.price}</span>
                <span className="text-sm text-gray-400 line-through mb-1">MRP ₹{product.originalPrice}</span>
                <span className="text-[10px] font-bold bg-gray-800 text-white px-1.5 py-0.5 rounded mb-1 bg-opacity-70">{product.discount} Off</span>
              </div>
              <p className="text-[10px] text-gray-400">(incl. of all taxes)</p>
            </div>

            {/* Add to Cart Area */}
            <div className="flex gap-4 mb-8">
              <div className="flex items-center border border-gray-300 w-28 bg-white shrink-0">
                <button 
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-3 hover:bg-gray-50 transition-colors text-gray-500 w-1/3 flex items-center justify-center"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="w-1/3 text-center font-medium text-sm text-gray-800">{quantity}</span>
                <button 
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-3 hover:bg-gray-50 transition-colors text-gray-500 w-1/3 flex items-center justify-center"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
              <Button onClick={handleAddToCart} className="flex-1 bg-[#2C3437] hover:bg-black text-white h-[46px] rounded-none text-sm font-bold tracking-widest uppercase transition-all duration-300">
                Add to Cart
              </Button>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-2 gap-y-4 gap-x-2 mb-10 py-5 border-y border-gray-100">
              <div className="flex items-center gap-2.5 text-xs text-gray-600 font-medium">
                <Shield className="w-4 h-4 text-[#E36940]" /> Secure Payment
              </div>
              <div className="flex items-center gap-2.5 text-xs text-gray-600 font-medium">
                <Sparkles className="w-4 h-4 text-[#E36940]" /> Dermatologically Tested
              </div>
              <div className="flex items-center gap-2.5 text-xs text-gray-600 font-medium">
                <Check className="w-4 h-4 text-[#E36940]" /> 100% Authentic
              </div>
              <div className="flex items-center gap-2.5 text-xs text-gray-600 font-medium">
                <Droplets className="w-4 h-4 text-[#E36940]" /> Cruelty Free
              </div>
            </div>

            {/* Accordions */}
            <div className="border-t border-gray-200">
              {tabs.map((tab) => (
                <div key={tab.id} className="border-b border-gray-200">
                  <button
                    onClick={() => setActiveTab(activeTab === tab.id ? '' as any : tab.id as any)}
                    className="w-full flex justify-between items-center py-4 text-sm font-medium text-gray-800 hover:text-black hover:bg-gray-50/50 transition-colors"
                  >
                    {tab.label}
                    <Plus className={cn("w-4 h-4 text-gray-400 transition-transform duration-300", activeTab === tab.id ? "rotate-45" : "")} />
                  </button>
                  <AnimatePresence initial={false}>
                    {activeTab === tab.id && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3, ease: 'easeInOut' }}
                        className="overflow-hidden"
                      >
                        <div className="pb-6 text-sm text-gray-600 leading-relaxed font-medium">
                          {tab.id === 'benefits' && (
                            <ul className="space-y-2 list-disc pl-4 marker:text-gray-300">
                               {product.benefits.map((b: string, i: number) => <li key={i}>{b}</li>)}
                            </ul>
                          )}
                          {tab.id === 'ingredients' && (
                            <div className="space-y-4">
                              {product.ingredients.map((ing: any, i: number) => (
                                <p key={i}><strong className="text-gray-800">{ing.name}:</strong> {ing.desc}</p>
                              ))}
                              <p className="text-xs text-gray-400 mt-4 border-t border-gray-100 pt-4 leading-relaxed">
                                {product.otherIngredients}
                              </p>
                            </div>
                          )}
                          {tab.id === 'howtouse' && (
                            <div className="space-y-3">
                               {product.howToUse.map((step: string, i: number) => (
                                  <div key={i} className="flex gap-3">
                                    <span className="font-bold text-gray-300 w-4">{i + 1}.</span>
                                    <span>{step}</span>
                                  </div>
                               ))}
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>

          </div>
          
        </div>
      </div>
    </div>
  );
}
