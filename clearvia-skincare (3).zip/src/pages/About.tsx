import { motion } from 'motion/react';
import { Shield, Users, Leaf, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { BackButton } from '../components/BackButton';

export function About() {
  return (
    <div className="bg-white min-h-screen pt-12">
      <div className="max-w-4xl mx-auto px-4">
        <BackButton />
      </div>
      {/* Story Section */}
      <section className="py-12 border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-4 italic">Our Origin.</h1>
            <p className="text-sm font-bold uppercase tracking-[0.4em] text-teal-600 mb-12">the new standard</p>
            <p className="text-xl text-gray-500 leading-relaxed max-w-2xl mx-auto">
              Clearvia isn't just another skincare brand. We are a young, passionate team from India that decided to stop complaining about effective skincare being out of reach and started doing something about it.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
            <div className="aspect-square bg-gray-100 rounded-[3rem] overflow-hidden">
              <img 
               src="https://images.unsplash.com/photo-1542452255191-c85a98f2c5d1?auto=format&fit=crop&q=80&w=800" 
               alt="Skincare research" 
               className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
              />
            </div>
            <div className="space-y-8">
              <h2 className="text-4xl font-bold tracking-tight text-black">Radical Honesty.</h2>
              <p className="text-gray-500 text-lg leading-relaxed">
                When we started Clearvia, we had one goal: <strong>Transparency</strong>. We don't have 10,000 customers yet, and we aren't a multi-billion dollar corporation. We are a brand new company launching our first collection, and that's our core strength.
              </p>
              <p className="text-gray-500 text-lg leading-relaxed">
                Because we are small, we care more. We've spent months researching every single extract in our Essential Trio. We personally check every batch. We don't hide behind complex medical jargon; we just provide pure, effective care that works.
              </p>
              
              <div className="grid grid-cols-2 gap-8 pt-8">
                <div className="space-y-1">
                  <h4 className="text-3xl font-bold text-teal-600">ZERO</h4>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Hidden Toxins</p>
                </div>
                <div className="space-y-1">
                  <h4 className="text-3xl font-bold text-teal-600">PURE</h4>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Ingredients</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h3 className="text-3xl sm:text-4xl font-bold tracking-tight text-black mb-6">Join the Journey.</h3>
          <p className="text-gray-500 max-w-xl mx-auto mb-10 text-lg">
            We are just getting started. When you choose our Essential Trio, you aren't just buying products—you're supporting a new standard in skincare.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
            <a href="https://wa.me/message/3MPLW7S7QCJWC1" target="_blank" rel="noopener noreferrer" className="bg-black text-white px-10 py-5 rounded-full font-bold hover:bg-teal-500 transition-all">Support Us on WhatsApp</a>
            <Link to="/shop" className="border border-black text-black px-10 py-5 rounded-full font-bold hover:bg-black hover:text-white transition-all">Explore products</Link>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 uppercase tracking-widest text-black font-bold">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
          <div className="flex flex-col items-center gap-4">
            <Shield className="w-8 h-8 text-teal-500" />
            <span className="text-[10px]">Safe Formula</span>
          </div>
          <div className="flex flex-col items-center gap-4">
            <Users className="w-8 h-8 text-teal-500" />
            <span className="text-[10px]">Community First</span>
          </div>
          <div className="flex flex-col items-center gap-4">
            <Leaf className="w-8 h-8 text-teal-500" />
            <span className="text-[10px]">Clean Label</span>
          </div>
          <div className="flex flex-col items-center gap-4">
            <Heart className="w-8 h-8 text-teal-500" />
            <span className="text-[10px]">Made with Love</span>
          </div>
        </div>
      </section>
    </div>
  );
}
