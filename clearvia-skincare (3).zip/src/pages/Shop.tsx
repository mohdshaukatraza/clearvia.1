import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Button } from '../components/Button';
import { productsListData as productsList } from '../data/products';
import { BackButton } from '../components/BackButton';

export function Shop() {
  return (
    <div className="bg-white min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <BackButton />
        <div className="text-center mb-16">
          <div className="inline-block bg-teal-50 text-teal-700 px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest mb-8 border border-teal-100">
            🎉 Extra 5% Off on all prepaid orders!
          </div>
          <h1 className="text-4xl sm:text-6xl font-bold tracking-tighter mb-4 italic">Shop Collection.</h1>
          <p className="text-sm font-bold uppercase tracking-[0.4em] text-teal-600 mb-6">the new standard</p>
          <p className="text-gray-500 max-w-xl mx-auto">Explore our pure, effective formulations designed specifically for Indian skin. Build your routine.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {productsList.map((product, idx) => (
            <motion.div 
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="group flex flex-col bg-gray-50 rounded-[2rem] overflow-hidden border border-gray-100 hover:shadow-xl transition-all"
            >
              <Link to={`/product/${product.id}`} className="relative aspect-[4/3] overflow-hidden block">
                {product.tag && (
                  <div className="absolute top-6 left-6 z-10 px-3 py-1 bg-white text-black text-[10px] font-bold uppercase tracking-widest rounded-full shadow-sm">
                    {product.tag}
                  </div>
                )}
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </Link>
              <div className="p-8 flex flex-col flex-1">
                <p className="text-teal-600 text-[10px] font-bold uppercase tracking-widest mb-2">{product.subtitle}</p>
                <h3 className="text-2xl font-bold tracking-tight text-black mb-4">{product.name}</h3>
                <div className="mt-auto flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-xl font-bold text-teal-600">₹{product.price}</span>
                    <span className="text-sm text-gray-400 line-through">₹{product.originalPrice}</span>
                  </div>
                  <Link to={`/product/${product.id}`}>
                    <Button variant="outline" className="rounded-full px-6">View Details</Button>
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
