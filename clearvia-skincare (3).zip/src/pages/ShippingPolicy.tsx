import { motion } from 'motion/react';
import { BackButton } from '../components/BackButton';

export function ShippingPolicy() {
  return (
    <div className="bg-white min-h-screen py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <BackButton />
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16"
        >
          <h1 className="text-4xl sm:text-6xl font-bold tracking-tighter mb-8 italic">Shipping Policy.</h1>
          <p className="text-sm font-bold uppercase tracking-[0.4em] text-teal-600 mb-12">the new standard</p>
        </motion.div>

        <div className="space-y-16">
          <section>
            <h2 className="text-2xl font-bold text-black mb-6 uppercase tracking-widest">Delivery Details</h2>
            <div className="prose prose-sm text-gray-500 max-w-none space-y-4">
              <p>At Clearvia, we understand you are excited to receive your products. We aim to process and ship all orders within 24-48 hours of placement.</p>
              <div className="bg-gray-50 p-6 border border-gray-100 rounded-2xl">
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <span className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-1.5 flex-shrink-0" />
                    <span><strong>Standard Delivery:</strong> 3-7 business days across India.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-1.5 flex-shrink-0" />
                    <span><strong>Order Tracking:</strong> You will receive a tracking link via WhatsApp/SMS once shipped.</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-1.5 flex-shrink-0" />
                    <span><strong>Shipping Charges:</strong> Free shipping on the Essential Trio Launch Combo.</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="bg-black text-white p-8 sm:p-12 rounded-[2rem]">
            <h2 className="text-xl font-bold mb-6 uppercase tracking-widest">Need help with tracking?</h2>
            <p className="text-gray-400 mb-8 max-w-md">Our support team is available from 10:00 AM to 6:00 PM (Monday - Saturday).</p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="https://wa.me/message/3MPLW7S7QCJWC1" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-white text-black px-8 py-4 rounded-full font-bold text-center hover:bg-teal-500 hover:text-white transition-all"
              >
                WhatsApp Us
              </a>
              <a 
                href="tel:+919717023665" 
                className="border border-white/20 text-white px-8 py-4 rounded-full font-bold text-center hover:bg-white hover:text-black transition-all"
              >
                Call: 9717023665
              </a>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
