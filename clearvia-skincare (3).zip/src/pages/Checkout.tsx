import React, { useState, useEffect } from 'react';
import { useCart } from '../context/CartContext';
import { Button } from '../components/Button';
import { ShieldCheck, Truck, CreditCard, ArrowLeft, Trash2, Plus, Minus, MapPin, Package, CheckCircle, Home } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { productsData } from '../data/products';

export function Checkout() {
  const { cartItemsCount, items, addToCart, removeFromCart } = useCart();
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const [paymentMethod, setPaymentMethod] = useState('card');
  const [showPaymentGateway, setShowPaymentGateway] = useState(false);

  const subtotal = items.reduce((sum, item) => {
    const product = productsData[item.id];
    return sum + (product ? product.price * item.quantity : 0);
  }, 0);
  
  const discountAmount = Math.floor(subtotal * 0.05); // 5% off
  const subtotalAfterDiscount = subtotal - discountAmount;

  const hasShipping = items.some(item => !productsData[item.id]?.freeShipping);
  const shipping = hasShipping && subtotalAfterDiscount < 500 ? 50 : 0; 
  const total = subtotalAfterDiscount + shipping;

  const suggestedProductIds = Object.keys(productsData).filter(id => !items.some(item => item.id === id)).slice(0, 2);

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [pincode, setPincode] = useState('');
  const [phone, setPhone] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!firstName.trim()) newErrors.firstName = 'First name is required';
    if (!address.trim()) newErrors.address = 'Address is required';
    if (!city.trim()) newErrors.city = 'City is required';
    if (!state.trim()) newErrors.state = 'State is required';
    if (!pincode.trim()) {
      newErrors.pincode = 'PIN Code is required';
    } else if (!/^\d{6}$/.test(pincode)) {
      newErrors.pincode = 'Invalid PIN Code. Must be 6 digits.';
    }
    if (!phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^\+?\d{10,12}$/.test(phone)) {
      newErrors.phone = 'Invalid phone number format.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleProceedToPayment = () => {
    if (validateForm()) {
      setShowPaymentGateway(true);
    }
  };

  const handlePaymentComplete = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setShowPaymentGateway(false);
      setIsSuccess(true);
    }, 2000);
  };

  if (showPaymentGateway) {
    return (
      <div className="bg-gray-50 min-h-screen py-12 lg:py-24 px-4">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row gap-8 items-start">
          
          <div className="bg-white p-8 md:p-12 shadow-xl border border-gray-100 w-full relative flex-1">
            <button 
              type="button" 
              onClick={() => setShowPaymentGateway(false)} 
              className="absolute top-4 left-4 p-2 text-gray-400 hover:text-black transition-colors"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            
            <div className="text-center mb-8 pt-4">
              <h2 className="text-2xl font-bold tracking-tight text-black mb-2">Payment Method</h2>
              <p className="text-gray-500 text-sm">Choose how you want to pay.</p>
            </div>

            <div className="bg-gray-50 p-6 mb-8 text-center border border-gray-200">
              <p className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-2">Amount to Pay</p>
              <p className="text-4xl font-bold text-teal-600">₹{total}</p>
            </div>

            <div className="grid grid-cols-4 gap-2 mb-8">
              <label className={`border border-gray-200 p-2 cursor-pointer flex flex-col items-center gap-1 transition-colors overflow-hidden ${paymentMethod === 'card' ? 'border-black bg-gray-50 ring-1 ring-black' : 'hover:border-black'}`}>
                <input type="radio" name="payment" className="hidden" checked={paymentMethod === 'card'} onChange={() => setPaymentMethod('card')} />
                <CreditCard className="w-4 h-4" />
                <span className="text-[9px] font-bold uppercase tracking-wide text-center">Card</span>
              </label>
              <label className={`border border-gray-200 p-2 cursor-pointer flex flex-col items-center gap-1 transition-colors overflow-hidden ${paymentMethod === 'upi' ? 'border-black bg-gray-50 ring-1 ring-black' : 'hover:border-black'}`}>
                <input type="radio" name="payment" className="hidden" checked={paymentMethod === 'upi'} onChange={() => setPaymentMethod('upi')} />
                <div className="text-sm font-bold leading-none">UPI</div>
                <span className="text-[9px] mt-1 font-bold uppercase tracking-wide text-center">App</span>
              </label>
              <label className={`border border-gray-200 p-2 cursor-pointer flex flex-col items-center gap-1 transition-colors overflow-hidden ${paymentMethod === 'bank' ? 'border-black bg-gray-50 ring-1 ring-black' : 'hover:border-black'}`}>
                <input type="radio" name="payment" className="hidden" checked={paymentMethod === 'bank'} onChange={() => setPaymentMethod('bank')} />
                <div className="text-sm font-bold leading-none">NB</div>
                <span className="text-[9px] mt-1 font-bold uppercase tracking-wide text-center">Bank</span>
              </label>
              <label className={`border border-gray-200 p-2 cursor-pointer flex flex-col items-center gap-1 transition-colors overflow-hidden ${paymentMethod === 'cod' ? 'border-black bg-gray-50 ring-1 ring-black' : 'hover:border-black'}`}>
                <input type="radio" name="payment" className="hidden" checked={paymentMethod === 'cod'} onChange={() => setPaymentMethod('cod')} />
                <Truck className="w-4 h-4" />
                <span className="text-[9px] font-bold uppercase tracking-wide text-center">COD</span>
              </label>
            </div>

            {paymentMethod === 'card' && (
              <div className="space-y-4 mb-8">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Card Number</label>
                  <input type="text" placeholder="XXXX XXXX XXXX XXXX" className="w-full bg-gray-50 border-0 p-3 focus:ring-2 focus:ring-black outline-none text-sm font-mono tracking-widest" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Expiry (MM/YY)</label>
                    <input type="text" placeholder="12/25" className="w-full bg-gray-50 border-0 p-3 focus:ring-2 focus:ring-black outline-none text-sm font-mono tracking-widest" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">CVV</label>
                    <input type="password" placeholder="***" maxLength={3} className="w-full bg-gray-50 border-0 p-3 focus:ring-2 focus:ring-black outline-none text-sm font-mono tracking-widest" />
                  </div>
                </div>
                <div className="bg-gray-50 p-4 flex items-start gap-4">
                  <ShieldCheck className="w-4 h-4 text-teal-600 mt-0.5" />
                  <p className="text-[10px] text-gray-500 leading-relaxed italic">
                    Your payment information is encrypted.
                  </p>
                </div>
              </div>
            )}

            {paymentMethod === 'upi' && (
              <div className="text-center mb-8 border-2 border-dashed border-gray-200 p-6">
                <div className="w-40 h-40 bg-gray-100 mx-auto mb-4 flex items-center justify-center">
                  <span className="text-gray-400 font-bold uppercase text-[10px] tracking-widest cursor-pointer hover:text-black">Show QR Code</span>
                </div>
                <p className="text-xs text-gray-500 mb-4">Scan with Google Pay, PhonePe, etc.</p>
                <div className="text-[10px] uppercase tracking-widest text-gray-400 mb-2 font-bold">OR UPI ID</div>
                <input type="text" placeholder="user@bank" className="w-full bg-gray-50 border-0 p-3 focus:ring-2 focus:ring-black outline-none text-sm text-center" />
              </div>
            )}

            {paymentMethod === 'bank' && (
              <div className="mb-8 space-y-4">
                <p className="text-sm text-gray-500 mb-4 text-center">Select your bank for netbanking.</p>
                <select className="w-full bg-gray-50 border-0 p-4 focus:ring-2 focus:ring-black outline-none text-sm">
                  <option>HDFC Bank</option>
                  <option>ICICI Bank</option>
                  <option>State Bank of India</option>
                  <option>Axis Bank</option>
                  <option>Kotak Mahindra Bank</option>
                </select>
              </div>
            )}

            {paymentMethod === 'cod' && (
              <div className="mb-8 p-6 bg-gradient-to-br from-amber-50 to-orange-50 border border-orange-100/50 rounded-3xl">
                <div className="flex justify-center mb-4">
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm">
                    <Truck className="w-6 h-6 text-orange-500" />
                  </div>
                </div>
                <p className="text-lg text-black font-bold text-center tracking-tight mb-6">Cash on Delivery</p>
                <div className="bg-white p-5 rounded-2xl shadow-sm border border-orange-50 space-y-4 mb-4">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-500 font-medium">Advance to pay now</span>
                    <span className="font-bold text-black text-lg">₹350</span>
                  </div>
                  <div className="h-px w-full bg-gray-100"></div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-500 font-medium">To pay on delivery</span>
                    <span className="font-bold text-gray-400">₹{total - 350}</span>
                  </div>
                </div>
                <p className="text-xs text-orange-800/70 font-medium text-center px-4 leading-relaxed">
                  An advance payment of ₹350 is required to confirm COD orders and prevent cancellations.
                </p>
              </div>
            )}

            <Button 
              className="w-full bg-black hover:bg-gray-800 text-white rounded-2xl py-6 shadow-xl hover:shadow-2xl transition-all" 
              size="xl" 
              onClick={handlePaymentComplete}
              isLoading={isProcessing}
            >
              {paymentMethod === 'cod' ? 'Pay ₹350 Advance' : `Securely Pay ₹${total}`}
            </Button>

            {paymentMethod !== 'cod' && (
              <div className="mt-6 flex items-center justify-center gap-2">
                <ShieldCheck className="w-4 h-4 text-green-500" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">100% Secure Payment</span>
              </div>
            )}
          </div>

          <div className="w-full md:w-80 lg:w-96 hidden md:block shrink-0">
             <div className="bg-white p-6 shadow-sm border border-gray-100 flex flex-col gap-6 sticky top-8">
                <div className="flex justify-between items-center border-b border-gray-100 pb-4">
                  <h3 className="font-bold uppercase tracking-widest text-sm">Order Summary</h3>
                  <span className="bg-teal-50 text-teal-700 px-2 py-1 text-[10px] font-bold rounded">{items.length} Items</span>
                </div>
                
                <div className="space-y-4">
                  {items.map((item) => {
                    const product = productsData[item.id];
                    if (!product) return null;
                    return (
                      <div key={item.id} className="flex gap-4">
                        <img src={product.images[0]} alt={product.name} className="w-16 h-16 object-cover bg-gray-50" />
                        <div className="flex-1 text-sm">
                          <p className="font-bold text-xs uppercase tracking-wide leading-tight mb-1">{product.name}</p>
                          <p className="text-gray-500 text-xs">Qty: {item.quantity}</p>
                        </div>
                      </div>
                    )
                  })}
                </div>
                
                <div className="border-t border-gray-100 pt-4 space-y-2">
                  <div className="flex justify-between text-sm text-gray-500">
                    <span>Subtotal</span>
                    <span>₹{subtotal}</span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-sm text-teal-600 font-bold">
                      <span>Extra 5% Off</span>
                      <span>-₹{discountAmount}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-sm text-gray-500">
                    <span>Shipping</span>
                    <span>{shipping === 0 ? 'FREE' : `₹${shipping}`}</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 border-t border-gray-100 mt-2">
                    <span className="font-bold uppercase tracking-widest">Total</span>
                    <span className="font-bold text-teal-600 text-lg">₹{total}</span>
                  </div>
                </div>
             </div>
          </div>
        </div>
      </div>
    );
  }

  if (isSuccess) {
    return (
      <div className="bg-gray-50 min-h-screen py-12 lg:py-24">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100 mb-8 text-center max-w-xl mx-auto">
            <motion.div 
               initial={{ scale: 0 }}
               animate={{ scale: 1 }}
               className="w-20 h-20 bg-teal-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-teal-500/30"
            >
              <CheckCircle className="w-10 h-10 text-white" />
            </motion.div>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-black mb-4">Order Confirmed!</h2>
            <p className="text-gray-500 mb-6 max-w-sm mx-auto">Thank you for your purchase. We've sent an email with your order details.</p>
            <p className="text-sm font-bold text-black border border-gray-200 inline-block px-4 py-2 rounded-lg bg-gray-50 tracking-widest">ORDER #ORD-{Math.floor(100000 + Math.random() * 900000)}</p>
          </div>

          <div className="bg-white rounded-3xl p-6 md:p-12 shadow-sm border border-gray-100 max-w-xl mx-auto">
            <h3 className="text-xl font-bold tracking-tight text-black mb-10 border-b border-gray-100 pb-4 text-center">Track Your Order</h3>
            
            <div className="relative border-l-2 border-gray-100 ml-4 md:ml-8 space-y-12">
              
              {/* Step 1: Placed (Completed) */}
              <div className="relative pl-8 md:pl-12">
                <div className="absolute -left-[17px] top-0 bg-teal-500 rounded-full p-2 ring-8 ring-white shadow-sm">
                   <Package className="w-4 h-4 text-white" />
                </div>
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-black text-lg leading-none mb-2">Order Placed</h4>
                    <p className="text-sm text-gray-500 max-w-xs">We have received your order.</p>
                  </div>
                  <div className="text-[10px] font-bold uppercase tracking-widest text-teal-600 bg-teal-50 px-2 py-1 rounded w-fit">Done</div>
                </div>
              </div>

              {/* Step 2: Processing (Active) */}
              <div className="relative pl-8 md:pl-12">
                <div className="absolute -left-[17px] top-0 bg-white border-2 border-teal-500 rounded-full p-2.5 ring-8 ring-white shadow-sm shadow-teal-500/20">
                   <div className="w-2.5 h-2.5 bg-teal-500 rounded-full animate-pulse" />
                </div>
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-black text-lg leading-none mb-2">Processing</h4>
                    <p className="text-sm text-gray-500 max-w-xs">Items are being packed securely.</p>
                  </div>
                  <div className="text-[10px] font-bold uppercase tracking-widest text-orange-600 bg-orange-50 px-2 py-1 rounded w-fit flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span> In Progress
                  </div>
                </div>
              </div>

              {/* Step 3: Shipped (Upcoming) */}
              <div className="relative pl-8 md:pl-12 opacity-40">
                <div className="absolute -left-[17px] top-0 bg-gray-50 border-2 border-gray-200 rounded-full p-2 ring-8 ring-white">
                   <Truck className="w-4 h-4 text-gray-400" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-700 text-lg leading-none mb-2">Shipped</h4>
                  <p className="text-sm text-gray-500 max-w-xs">Handed over to delivery partner.</p>
                </div>
              </div>

              {/* Step 4: Delivered (Upcoming) */}
              <div className="relative pl-8 md:pl-12 opacity-40">
                <div className="absolute -left-[17px] top-0 bg-gray-50 border-2 border-gray-200 rounded-full p-2 ring-8 ring-white">
                   <Home className="w-4 h-4 text-gray-400" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-700 text-lg leading-none mb-2">Delivered</h4>
                  <p className="text-sm text-gray-500 max-w-xs">Successfully delivered to you.</p>
                </div>
              </div>

            </div>

            <div className="mt-12 pt-8 border-t border-gray-100 flex justify-center">
              <Link to="/">
                <Button size="xl" className="w-full sm:w-auto px-10 bg-black hover:bg-teal-600 text-white rounded-2xl shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 flex items-center justify-center gap-2 group">
                  Continue Shopping <ArrowLeft className="w-5 h-5 rotate-180 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (cartItemsCount === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] px-4 text-center">
        <div className="text-6xl mb-8">🧴</div>
        <h2 className="text-3xl font-bold text-black mb-4">Your cart is empty</h2>
        <p className="text-gray-500 mb-8 max-w-sm">Looks like you haven't added the routine yet. Beautiful skin is just a click away.</p>
        <Link to="/shop">
          <Button>Shop the Combo</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen py-12 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-4 mb-12">
          <Link to="/shop" className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-500">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-4xl font-bold tracking-tight text-black">Checkout</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12 items-start">
          
          {/* Main Display */}
          <div className="lg:col-span-2 order-2 lg:order-1">
            <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-gray-100 mb-8">
               <h3 className="text-xl font-bold tracking-tight text-black mb-8">1. Delivery Information</h3>
               
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">First Name *</label>
                    <input type="text" value={firstName} onChange={e => { setFirstName(e.target.value); if(errors.firstName) setErrors({...errors, firstName: ''}); }} className={`w-full border p-4 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none transition-all text-sm ${errors.firstName ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-[#F7FAFA]'}`} placeholder="First Name" />
                    {errors.firstName && <p className="text-red-500 text-xs mt-1 font-medium">{errors.firstName}</p>}
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Last Name (Optional)</label>
                    <input type="text" value={lastName} onChange={e => setLastName(e.target.value)} className="w-full border border-gray-200 p-4 rounded-xl bg-[#F7FAFA] focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none transition-all text-sm" placeholder="Last Name" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Email Address (Optional)</label>
                    <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full border border-gray-200 p-4 rounded-xl bg-[#F7FAFA] focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none transition-all text-sm" placeholder="your@email.com" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Shipping Address *</label>
                    <input type="text" value={address} onChange={e => { setAddress(e.target.value); if(errors.address) setErrors({...errors, address: ''}); }} className={`w-full border p-4 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none transition-all text-sm mb-4 ${errors.address ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-[#F7FAFA]'}`} placeholder="Street Address" />
                    {errors.address && <p className="text-red-500 text-xs mt-1 mb-4 font-medium -mt-2">{errors.address}</p>}
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                      <div className="col-span-2 sm:col-span-1">
                        <input type="text" value={city} onChange={e => { setCity(e.target.value); if(errors.city) setErrors({...errors, city: ''}); }} className={`w-full border p-4 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none transition-all text-sm ${errors.city ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-[#F7FAFA]'}`} placeholder="City" />
                        {errors.city && <p className="text-red-500 text-xs mt-1 font-medium">{errors.city}</p>}
                      </div>
                      <div>
                        <input type="text" value={state} onChange={e => { setState(e.target.value); if(errors.state) setErrors({...errors, state: ''}); }} className={`w-full border p-4 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none transition-all text-sm ${errors.state ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-[#F7FAFA]'}`} placeholder="State" />
                        {errors.state && <p className="text-red-500 text-xs mt-1 font-medium">{errors.state}</p>}
                      </div>
                      <div>
                        <input type="text" value={pincode} onChange={e => { setPincode(e.target.value); if(errors.pincode) setErrors({...errors, pincode: ''}); }} className={`w-full border p-4 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none transition-all text-sm ${errors.pincode ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-[#F7FAFA]'}`} placeholder="PIN Code" />
                        {errors.pincode && <p className="text-red-500 text-xs mt-1 font-medium">{errors.pincode}</p>}
                      </div>
                    </div>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Phone Number *</label>
                    <input type="tel" value={phone} onChange={e => { setPhone(e.target.value); if(errors.phone) setErrors({...errors, phone: ''}); }} className={`w-full border p-4 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none transition-all text-sm ${errors.phone ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-[#F7FAFA]'}`} placeholder="+91" />
                    {errors.phone && <p className="text-red-500 text-xs mt-1 font-medium">{errors.phone}</p>}
                  </div>
               </div>
               
               <h3 className="text-xl font-bold tracking-tight text-black mb-6 pt-6 border-t border-gray-100">2. Secure Payment</h3>
               <p className="text-sm text-gray-500 mb-8">All transactions are secure and encrypted. You can also choose Cash on Delivery directly here.</p>

               {Object.keys(errors).length > 0 && (
                 <div className="mb-6 p-4 bg-red-50 text-red-600 text-sm rounded-xl border border-red-100 flex items-start gap-3">
                   <div className="mt-0.5">⚠️</div>
                   <p className="font-medium">Please fill in all the required information correctly to proceed to payment.</p>
                 </div>
               )}

               <Button 
                 size="xl" 
                 onClick={handleProceedToPayment} 
                 className="w-full bg-teal-600 hover:bg-teal-700 text-white rounded-2xl shadow-lg hover:shadow-xl transition-all border-0 py-6"
               >
                 <ShieldCheck className="w-5 h-5 mr-2" /> Continue to Secure Payment
               </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 hidden lg:grid">
              <div className="bg-white p-6 shadow-sm border border-gray-100 flex gap-4">
                <div className="w-12 h-12 bg-teal-50 rounded-full flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-6 h-6 text-teal-600" />
                </div>
                <div>
                   <h4 className="font-bold text-sm uppercase tracking-widest text-black mb-2">Authentic Products</h4>
                   <p className="text-xs text-gray-500 leading-relaxed">Directly from the manufacturer. 100% genuine formulations guaranteed.</p>
                </div>
              </div>
              <div className="bg-white p-6 shadow-sm border border-gray-100 flex gap-4">
                <div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center shrink-0">
                  <Truck className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                   <h4 className="font-bold text-sm uppercase tracking-widest text-black mb-2">Fast & Safe Delivery</h4>
                   <p className="text-xs text-gray-500 leading-relaxed">Dispatched within 24 hours. Delivered directly to your door.</p>
                </div>
              </div>
              
              <div className="sm:col-span-2 mt-4 bg-gray-50 p-8 border border-gray-100 text-center">
                 <h4 className="font-bold text-sm uppercase tracking-widest text-black mb-6">Why shop with us?</h4>
                 <p className="text-sm text-gray-500 max-w-lg mx-auto italic mb-6">"I've been using Clearvia for 6 months and it completely transformed my daily routine. The checkout process is seamless and the delivery is always on time."</p>
                 <div className="flex justify-center text-yellow-400 gap-1 mb-3 text-lg">★★★★★</div>
                 <p className="text-xs text-gray-400 font-bold tracking-widest uppercase">Priya S. — Verified Buyer</p>
                 <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150" alt="Customer" className="w-10 h-10 rounded-full mx-auto mt-4 object-cover border-2 border-white shadow-sm" />
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <aside className="order-1 lg:order-2 bg-white p-6 lg:p-8 shadow-sm border border-gray-100 lg:sticky lg:top-24">
            <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-6 lg:mb-8">Order Summary</h3>
            
            <div className="space-y-4 lg:space-y-6 mb-6 lg:mb-8 border-b border-gray-100 pb-6 lg:pb-8">
              {items.map((cartItem) => {
                const product = productsData[cartItem.id];
                if (!product) return null;
                return (
                  <div key={cartItem.id} className="flex gap-4 group">
                    <div className="w-16 lg:w-20 h-16 lg:h-20 bg-gray-100 flex-shrink-0">
                      <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex flex-col justify-between py-1 flex-1">
                      <div className="flex justify-between items-start gap-2">
                        <h4 className="text-xs lg:text-sm font-bold text-black uppercase tracking-wide leading-tight">{product.name}</h4>
                        <button 
                          onClick={() => removeFromCart(cartItem.id, true)} 
                          className="text-gray-400 hover:text-red-500 transition-colors p-1"
                          title="Remove item"
                          type="button"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="flex justify-between items-center mt-2">
                        <div className="flex items-center gap-2 border border-gray-200">
                          <button 
                            type="button" 
                            onClick={() => removeFromCart(cartItem.id)}
                            className="px-2 py-1 hover:bg-gray-50 transition-colors"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-[10px] lg:text-xs font-bold w-4 text-center">{cartItem.quantity}</span>
                          <button 
                            type="button" 
                            onClick={() => addToCart(cartItem.id)}
                            className="px-2 py-1 hover:bg-gray-50 transition-colors"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <div className="flex flex-col items-end">
                          {product.originalPrice && (
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-[10px] text-gray-400 line-through">₹{product.originalPrice * cartItem.quantity}</span>
                              <span className="text-[8px] bg-teal-50 text-teal-700 px-1 py-0.5 rounded font-bold uppercase tracking-wider">{product.discount}</span>
                            </div>
                          )}
                          <span className="text-sm lg:text-base font-bold text-teal-600">₹{product.price * cartItem.quantity}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="space-y-3 lg:space-y-4 text-xs lg:text-sm mb-6 lg:mb-8">
              <div className="flex justify-between items-center text-gray-500">
                <span>Subtotal</span>
                <span>₹{subtotal}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between items-center text-teal-600 font-bold">
                  <span>Extra 5% Off</span>
                  <span>-₹{discountAmount}</span>
                </div>
              )}
              <div className="flex justify-between items-center text-gray-500">
                <span>Shipping</span>
                <span className="text-teal-600 font-bold uppercase text-[10px] lg:text-xs">
                  {shipping === 0 ? 'Free' : `₹${shipping}`}
                </span>
              </div>
              <div className="flex justify-between items-center text-lg lg:text-xl font-bold text-black pt-4 border-t border-gray-100">
                <span>Total</span>
                <span>₹{total}</span>
              </div>
            </div>

            {shipping === 0 && (
              <div className="bg-teal-50 p-4 flex gap-3 text-[10px] lg:text-xs mb-8">
                <span className="text-teal-600">✨</span>
                <p className="text-teal-800 leading-relaxed italic">You have unlocked Free Shipping!</p>
              </div>
            )}

            {suggestedProductIds.length > 0 && (
              <div className="mt-8 pt-8 border-t border-gray-100">
                <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-6">You Might Also Like</h3>
                <div className="space-y-4">
                  {suggestedProductIds.map(id => {
                    const product = productsData[id];
                    return (
                      <div key={id} className="flex gap-4 group items-center">
                        <Link to={`/product/${id}`} className="w-16 h-16 bg-gray-100 flex-shrink-0 block overflow-hidden">
                          <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                        </Link>
                        <div className="flex flex-col justify-between py-1 flex-1">
                          <Link to={`/product/${id}`}>
                            <h4 className="text-xs font-bold text-black uppercase tracking-wide leading-tight hover:text-teal-600 transition-colors">{product.name}</h4>
                          </Link>
                          <div className="flex justify-between items-center mt-2">
                            <span className="text-sm font-bold text-teal-600">₹{product.price}</span>
                            <button 
                              type="button" 
                              onClick={() => addToCart(id)}
                              className="text-[10px] font-bold uppercase tracking-widest bg-black text-white px-3 py-1.5 hover:bg-teal-600 transition-colors"
                            >
                              Add
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </aside>
        </div>
      </div>
    </div>
  );
}

