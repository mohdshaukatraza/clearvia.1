import { motion } from 'motion/react';
import { BackButton } from '../components/BackButton';

export function RefundPolicy() {
  return (
    <div className="bg-white min-h-screen py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <BackButton />
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16"
        >
          <h1 className="text-4xl sm:text-6xl font-bold tracking-tighter mb-8 italic">Returns & Refunds.</h1>
          <p className="text-sm font-bold uppercase tracking-[0.4em] text-teal-600 mb-12">the new standard</p>
        </motion.div>

        <div className="space-y-16">
          <section>
            <h2 className="text-2xl font-bold text-black mb-6 uppercase tracking-widest">Our Commitment</h2>
            <div className="prose prose-sm text-gray-500 max-w-none space-y-4">
              <p>Since we deal in personal care products, we have a restricted return policy for hygiene reasons. However, your satisfaction is our priority.</p>
              <div className="space-y-6">
                <div>
                  <h4 className="font-bold text-black mb-2">Damaged or Incorrect Items</h4>
                  <p>If you receive a damaged product or the wrong item, please contact us within 48 hours of delivery. We will provide a free replacement or a full refund.</p>
                </div>
                <div>
                  <h4 className="font-bold text-black mb-2">Eligibility for Return</h4>
                  <p>To be eligible, the product must be unused, seals should be intact, and in its original packaging. Please share an unboxing video with our helpline for faster processing.</p>
                </div>
                <div>
                  <h4 className="font-bold text-black mb-2">Refund Process</h4>
                  <p>Once your return is inspected and approved, we will initiate a refund to your original payment method. For Cash on Delivery (COD) orders, we will request your bank details for a bank transfer.</p>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-black text-white p-8 sm:p-12 rounded-[2rem]">
            <h2 className="text-xl font-bold mb-6 uppercase tracking-widest">Questions about refunds?</h2>
            <p className="text-gray-400 mb-8 max-w-md">Reach out to our support for quick resolutions.</p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="https://wa.me/message/3MPLW7S7QCJWC1" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-white text-black px-8 py-4 rounded-full font-bold text-center hover:bg-teal-500 hover:text-white transition-all"
              >
                WhatsApp Us
              </a>
              <a 
                href="tel:+919717023665" 
                className="border border-white/20 text-white px-8 py-4 rounded-full font-bold text-center hover:bg-white hover:text-black transition-all"
              >
                Call: 9717023665
              </a>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
