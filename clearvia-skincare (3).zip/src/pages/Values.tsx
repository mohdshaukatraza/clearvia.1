import { motion } from 'motion/react';
import { BackButton } from '../components/BackButton';
import { Leaf, Shield, Heart, Sparkles } from 'lucide-react';

export function Values() {
  const values = [
    {
      icon: <Leaf className="w-8 h-8 text-teal-500" />,
      title: "Clean Formulations",
      desc: "Our products are formulated without parabens, sulfates, and harmful chemicals. We believe in keeping it clean and safe for your skin."
    },
    {
      icon: <Shield className="w-8 h-8 text-teal-500" />,
      title: "Science-Backed",
      desc: "Every product is developed with proven dermatological science, using active ingredients that deliver real visible results."
    },
    {
      icon: <Heart className="w-8 h-8 text-teal-500" />,
      title: "Indian Skin Focus",
      desc: "Specially formulated for the unique challenges of Indian skin and climate. We focus on hyperpigmentation, oil control, and humidity resistance."
    },
    {
      icon: <Sparkles className="w-8 h-8 text-teal-500" />,
      title: "No Compromise",
      desc: "We never compromise on quality or efficacy. From ingredient sourcing to final packaging, we ensure the best experience for you."
    }
  ];

  return (
    <div className="bg-white min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <BackButton />
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16"
        >
          <h1 className="text-4xl sm:text-6xl font-bold tracking-tighter mb-8 italic">Our Values.</h1>
          <p className="text-sm font-bold uppercase tracking-[0.4em] text-teal-600 mb-12">what drives us</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {values.map((val, idx) => (
            <div key={idx} className="bg-gray-50 p-8 rounded-3xl border border-gray-100">
              <div className="mb-6 bg-white w-16 h-16 rounded-full flex items-center justify-center shadow-sm">
                {val.icon}
              </div>
              <h3 className="text-xl font-bold text-black mb-4 uppercase tracking-wide">{val.title}</h3>
              <p className="text-gray-500 leading-relaxed">
                {val.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
