import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from '../components/Button';
import { Package, Truck, Home, CheckCircle, Search } from 'lucide-react';

export function TrackOrder() {
  const [orderId, setOrderId] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [orderStatus, setOrderStatus] = useState<'idle' | 'found' | 'not_found'>('idle');

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderId.trim()) return;

    setIsSearching(true);
    // Simulate API call
    setTimeout(() => {
      setIsSearching(false);
      // Let's pretend any ORD- prefix works, otherwise random
      if (orderId.toUpperCase().startsWith('ORD-')) {
        setOrderStatus('found');
      } else {
        setOrderStatus('not_found');
      }
    }, 1500);
  };

  return (
    <div className="pt-24 min-h-screen bg-gray-50 flex flex-col pt-32 pb-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-5xl font-bold tracking-tight text-black mb-4">Track Your Order</h1>
          <p className="text-gray-500 max-w-xl mx-auto">
            Enter your order tracking number to see real-time updates on your delivery status.
          </p>
        </div>

        <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-gray-100 max-w-xl mx-auto mb-8">
          <form onSubmit={handleTrack} className="flex gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input 
                type="text" 
                value={orderId}
                onChange={(e) => setOrderId(e.target.value)}
                placeholder="e.g. ORD-123456" 
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none transition-all"
                required
              />
            </div>
            <Button type="submit" isLoading={isSearching} className="px-8 whitespace-nowrap bg-teal-600 hover:bg-teal-700 text-white rounded-xl">
              Track
            </Button>
          </form>

          {orderStatus === 'not_found' && (
            <div className="mt-6 p-4 bg-red-50 text-red-600 text-sm rounded-xl text-center">
              We couldn't find an order with that number. Please check the ID format and try again.
            </div>
          )}
        </div>

        {orderStatus === 'found' && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl p-6 md:p-12 shadow-sm border border-gray-100 max-w-xl mx-auto"
          >
            <div className="flex justify-between items-center mb-10 border-b border-gray-100 pb-6">
              <div>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Order Details</p>
                <h3 className="text-xl font-bold text-black">{orderId.toUpperCase()}</h3>
              </div>
              <div className="text-right">
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Expected Delivery</p>
                <h3 className="text-lg font-bold text-teal-600">Within 5-7 Days</h3>
              </div>
            </div>
            
            <div className="relative border-l-2 border-gray-100 ml-4 md:ml-8 space-y-12">
              
              {/* Step 1: Placed (Completed) */}
              <div className="relative pl-8 md:pl-12">
                <div className="absolute -left-[17px] top-0 bg-teal-500 rounded-full p-2 ring-8 ring-white shadow-sm">
                   <Package className="w-4 h-4 text-white" />
                </div>
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-black text-lg leading-none mb-2">Order Placed</h4>
                    <p className="text-sm text-gray-500 max-w-xs">We have received your order.</p>
                  </div>
                  <div className="text-[10px] font-bold uppercase tracking-widest text-teal-600 bg-teal-50 px-2 py-1 rounded w-fit">Done</div>
                </div>
              </div>

              {/* Step 2: Processing (Active) */}
              <div className="relative pl-8 md:pl-12">
                <div className="absolute -left-[17px] top-0 bg-white border-2 border-teal-500 rounded-full p-2.5 ring-8 ring-white shadow-sm shadow-teal-500/20">
                   <div className="w-2.5 h-2.5 bg-teal-500 rounded-full animate-pulse" />
                </div>
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-black text-lg leading-none mb-2">Processing</h4>
                    <p className="text-sm text-gray-500 max-w-xs">Items are being packed securely.</p>
                  </div>
                  <div className="text-[10px] font-bold uppercase tracking-widest text-orange-600 bg-orange-50 px-2 py-1 rounded w-fit flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span> In Progress
                  </div>
                </div>
              </div>

              {/* Step 3: Shipped (Upcoming) */}
              <div className="relative pl-8 md:pl-12 opacity-40">
                <div className="absolute -left-[17px] top-0 bg-gray-50 border-2 border-gray-200 rounded-full p-2 ring-8 ring-white">
                   <Truck className="w-4 h-4 text-gray-400" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-700 text-lg leading-none mb-2">Shipped</h4>
                  <p className="text-sm text-gray-500 max-w-xs">Handed over to delivery partner.</p>
                </div>
              </div>

              {/* Step 4: Delivered (Upcoming) */}
              <div className="relative pl-8 md:pl-12 opacity-40">
                <div className="absolute -left-[17px] top-0 bg-gray-50 border-2 border-gray-200 rounded-full p-2 ring-8 ring-white">
                   <Home className="w-4 h-4 text-gray-400" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-700 text-lg leading-none mb-2">Delivered</h4>
                  <p className="text-sm text-gray-500 max-w-xs">Successfully delivered to you.</p>
                </div>
              </div>

            </div>
          </motion.div>
        )}

      </div>
    </div>
  );
}
