import { motion } from 'motion/react';
import { BackButton } from '../components/BackButton';

export function Terms() {
  return (
    <div className="bg-white min-h-screen py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <BackButton />
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16"
        >
          <h1 className="text-4xl sm:text-6xl font-bold tracking-tighter mb-8 italic">Terms & Conditions.</h1>
          <p className="text-sm font-bold uppercase tracking-[0.4em] text-teal-600 mb-12">Rules of usage</p>
        </motion.div>

        <div className="space-y-12">
          <section>
            <h2 className="text-xl font-bold text-black mb-4 uppercase tracking-widest">1. General</h2>
            <p className="text-gray-500 leading-relaxed mb-4">
              By accessing and placing an order with Clearvia, you confirm that you are in agreement with and bound by the terms of service contained below. These terms apply to the entire website and any email or other type of communication between you and Clearvia.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black mb-4 uppercase tracking-widest">2. Products</h2>
            <p className="text-gray-500 leading-relaxed mb-4">
              All products are subject to availability. We reserve the right to discontinue any product at any time. We have made every effort to display as accurately as possible the colors and images of our products that appear on the website.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black mb-4 uppercase tracking-widest">3. Pricing & Payments</h2>
            <p className="text-gray-500 leading-relaxed mb-4">
              Prices for our products are subject to change without notice. We reserve the right to modify or discontinue the Service without notice at any time. We accept various payment methods securely processed through our authorized payment gateways.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black mb-4 uppercase tracking-widest">4. User Account</h2>
            <p className="text-gray-500 leading-relaxed mb-4">
              If you create an account on the website, you are responsible for maintaining the security of your account and you are fully responsible for all activities that occur under the account. You must immediately notify us of any unauthorized uses of your account.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
