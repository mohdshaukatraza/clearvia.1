import { Link, useNavigate } from 'react-router-dom';
import { ShieldCheck, Zap, Sparkles, Star, ChevronRight, Clock, Camera, RefreshCw, X, CheckCircle, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../components/Button';
import { useRef, useState } from 'react';
import { useCart } from '../context/CartContext';
import { productsListData } from '../data/products';

export function Home() {
  const carouselRef = useRef<HTMLDivElement>(null);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [scanStep, setScanStep] = useState<'intro' | 'scanning' | 'results'>('intro');
  const { addToCart } = useCart();
  const navigate = useNavigate();

  const handleBuyNow = (id: string = 'combo') => {
    addToCart(id);
    navigate('/checkout');
  };

  const startAnalysis = () => {
    setShowAnalysis(true);
    setScanStep('intro');
  };

  const handleCapture = () => {
    setScanStep('scanning');
    setTimeout(() => {
      setScanStep('results');
    }, 3500);
  };

  const closeAnalysis = () => {
    setShowAnalysis(false);
  };

  const scrollNext = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollBy({ left: 400, behavior: 'smooth' });
    }
  };

  const scrollPrev = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollBy({ left: -400, behavior: 'smooth' });
    }
  };

  const benefits = [
    {
      title: 'Acne Control',
      description: 'Salicylic acid and Neem extract to fight active acne and prevent breakouts.',
      icon: <ShieldCheck className="w-8 h-8 text-teal-600" />,
    },
    {
      title: 'Oil Balancing',
      description: '10% Niacinamide to regulate sebum production and keep skin matte all day.',
      icon: <Zap className="w-8 h-8 text-teal-600" />,
    },
    {
      title: 'Deep Glow',
      description: 'Vitamin C and Hyaluronic acid for that natural, healthy radiance.',
      icon: <Sparkles className="w-8 h-8 text-teal-600" />,
    },
  ];

  const reviews = [
    {
      name: 'Rohan M.',
      rating: 5,
      comment: 'Finally a solution for my oily skin. The combo is a steal at ₹999.',
      location: 'Bangalore',
    },
    {
      name: 'Ananya S.',
      rating: 5,
      comment: 'The sunscreen is non-sticky! My acne has cleared up in just 2 weeks.',
      location: 'Delhi',
    },
    {
      name: 'Vikram K.',
      rating: 4,
      comment: 'Premium packaging and effective ingredients. Better than expensive brands.',
      location: 'Mumbai',
    },
    {
      name: 'Priya D.',
      rating: 5,
      comment: 'I was skeptical but these products actually deliver. My skin feels so much smoother.',
      location: 'Pune',
    },
    {
      name: 'Sahil V.',
      rating: 5,
      comment: 'Best decision for my grooming routine. Simple 3 steps and results are visible.',
      location: 'Chandigarh',
    },
    {
      name: 'Isha R.',
      rating: 5,
      comment: 'No white cast! That was my biggest worry with sunscreens. Clearvia solved it.',
      location: 'Hyderabad',
    },
    {
      name: 'Anjali M.',
      rating: 5,
      comment: 'Finally found something that works for my oily skin in this humidity.',
      location: 'Kolkata',
    },
    {
      name: 'Rahul K.',
      rating: 5,
      comment: 'The serum is a game changer for my acne scars. Highly recommend.',
      location: 'Delhi',
    },
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative pt-24 pb-16 lg:pt-32 lg:pb-32 flex items-center bg-[#FAF9F6] border-b border-gray-200">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center lg:text-left flex flex-col items-center lg:items-start"
            >
              <div className="inline-block bg-gray-600 text-white text-[10px] font-bold px-2 py-1 mb-8 uppercase tracking-[0.2em] w-max">
                New
              </div>
              <h1 className="text-5xl sm:text-7xl lg:text-[6rem] xl:text-[7rem] font-light tracking-tighter leading-[0.9] mb-4 text-black uppercase">
                Advanced <br />
                Pure Care<span className="font-bold">.</span>
              </h1>
              <div className="text-sm sm:text-lg font-bold uppercase tracking-[0.2em] sm:tracking-[0.3em] text-gray-500 mb-8">
                Skin, solved
              </div>
              <p className="text-base sm:text-lg text-gray-500 max-w-md mb-12 leading-relaxed text-center lg:text-left font-medium">
                A fresh perspective on skincare. Expertly crafted for acne-prone and oily skin, bringing together nature and precision.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 items-center w-full sm:w-auto">
                <Button className="w-full sm:w-auto bg-[#1C1C1C] hover:bg-black text-white h-[52px] rounded-none text-sm font-bold tracking-widest uppercase transition-all duration-300 px-10" onClick={() => handleBuyNow('combo')}>
                  Shop The Core Routine 
                </Button>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="relative w-full max-w-md mx-auto lg:max-w-none"
            >
              <div className="aspect-[4/5] sm:aspect-square lg:aspect-[4/5] relative overflow-hidden border border-gray-200 bg-white p-8">
                <img 
                  src="https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=1000" 
                  alt="Clearvia Skincare Combo" 
                  className="w-full h-full object-contain mix-blend-multiply"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Shop Collection Section */}
      <section id="shop-collection" className="py-24 bg-white border-t border-gray-100">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-light tracking-tight text-black max-w-2xl mx-auto">
              Shop The Collection.
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {productsListData.map((product) => (
              <div key={product.id} className="group flex flex-col transition-all duration-300">
                <Link to={`/product/${product.id}`} className="block relative aspect-[4/5] overflow-hidden bg-[#FAF9F6]">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover mix-blend-multiply group-hover:scale-105 transition-transform duration-700 ease-out p-6"
                  />
                  {product.tag && (
                    <div className="absolute top-4 left-4 bg-gray-900 text-white text-[10px] font-bold uppercase tracking-widest px-2 py-1">
                      {product.tag}
                    </div>
                  )}
                </Link>
                
                <div className="pt-6 flex flex-col flex-1">
                  <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">{product.subtitle}</div>
                  <Link to={`/product/${product.id}`} className="block group-hover:text-gray-600 transition-colors">
                    <h3 className="font-light text-lg leading-tight mb-3 min-h-[3.5rem]">{product.name}</h3>
                  </Link>
                  
                  <div className="mt-auto">
                    <div className="flex items-end gap-3 mb-6">
                      <span className="text-xl font-light leading-none">₹{product.price}</span>
                      <span className="text-xs text-gray-400 line-through mb-0.5">₹{product.originalPrice}</span>
                    </div>
                    
                    <Button 
                      className="w-full bg-white hover:bg-black text-black hover:text-white border border-black rounded-none h-[46px] text-xs font-bold uppercase tracking-widest transition-all duration-300"
                      onClick={() => handleBuyNow(product.id)}
                    >
                      Add To Cart
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 lg:py-24 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 lg:mb-20">
            <h2 className="text-xs font-bold uppercase tracking-[0.3em] text-teal-600 mb-4">Why Clearvia</h2>
            <p className="text-3xl md:text-5xl font-bold tracking-tight text-black max-w-2xl mx-auto">
              Real Science for Real Problems.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
            {benefits.map((benefit, index) => (
              <motion.div
                key={index}
                whileHover={{ y: -10 }}
                className="p-8 lg:p-10 bg-gray-50 border border-gray-100 hover:border-teal-200 transition-all group"
              >
                <div className="mb-6 transform group-hover:scale-110 transition-transform">{benefit.icon}</div>
                <h3 className="text-xl font-bold mb-4 text-black">{benefit.title}</h3>
                <p className="text-sm lg:text-base text-gray-500 leading-relaxed">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Product Highlight */}
      <section className="py-16 lg:py-24 bg-[#0A0A0A] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div className="order-2 lg:order-1">
              <img 
                src="https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&q=80&w=800" 
                alt="Product detail" 
                className="rounded-2xl lg:rounded-3xl border border-white/10 w-full"
              />
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-3xl sm:text-5xl font-bold tracking-tighter leading-tight mb-8">
                The 3-Step <br />
                Acne-Free Routine.
              </h2>
              <div className="space-y-8 lg:space-y-12">
                <div className="flex gap-4 sm:gap-6">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full border border-teal-500 flex items-center justify-center text-[10px] font-bold text-teal-500">01</div>
                  <div>
                    <h4 className="font-bold text-base sm:text-lg mb-2 uppercase tracking-wide">Deep Cleansing Face Wash</h4>
                    <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">Removes excess oil and impurities without stripping your skin of moisture.</p>
                  </div>
                </div>
                <div className="flex gap-4 sm:gap-6">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full border border-teal-500 flex items-center justify-center text-[10px] font-bold text-teal-500">02</div>
                  <div>
                    <h4 className="font-bold text-base sm:text-lg mb-2 uppercase tracking-wide">Acne-Defense Serum</h4>
                    <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">Concentrated formula targeting active breakouts and fading old scars.</p>
                  </div>
                </div>
                <div className="flex gap-4 sm:gap-6">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full border border-teal-500 flex items-center justify-center text-[10px] font-bold text-teal-500">03</div>
                  <div>
                    <h4 className="font-bold text-base sm:text-lg mb-2 uppercase tracking-wide">Ultra-Matte Sunscreen</h4>
                    <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">Zero white cast, SPF 50 protection that keeps you matte and protected.</p>
                  </div>
                </div>
              </div>
              <div className="mt-12 text-center lg:text-left">
                <Button variant="secondary" size="lg" className="w-full sm:w-auto" onClick={() => handleBuyNow('combo')}>
                  Buy the routine - ₹999
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SkinInsights AI Section */}
      <section className="py-24 bg-white border-t border-gray-100 overflow-hidden relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            
            <div className="relative">
               <div className="aspect-square bg-gray-100 rounded-[2rem] overflow-hidden relative shadow-2xl">
                 <img 
                   src="https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=1000" 
                   alt="Skin Analysis" 
                   className="w-full h-full object-cover"
                 />
                 
                 {/* UI Overlays */}
                 <div className="absolute top-1/4 left-1/4 w-32 hidden md:block">
                   <div className="w-3 h-3 rounded-full bg-white border-2 border-teal-500 shadow-[0_0_15px_rgba(20,184,166,0.6)] relative z-10" />
                   <div className="border-t border-white/50 w-full absolute top-[5px] left-3" />
                   <div className="absolute top-[-10px] left-full ml-2 bg-black/80 backdrop-blur text-white text-[10px] font-mono tracking-widest px-3 py-1 rounded">
                     HYDRATION: 82%
                   </div>
                 </div>

                 <div className="absolute bottom-1/3 right-1/4 w-40 hidden md:block">
                   <div className="w-3 h-3 rounded-full bg-white border-2 border-orange-500 shadow-[0_0_15px_rgba(249,115,22,0.6)] float-right relative z-10" />
                   <div className="border-t border-white/50 w-full absolute top-[5px] right-3" />
                   <div className="absolute top-[-10px] right-full mr-2 bg-black/80 backdrop-blur text-white text-[10px] font-mono tracking-widest px-3 py-1 rounded">
                     TEXTURE: UNEVEN
                   </div>
                 </div>
                 
                 {/* Scanning Line Animation */}
                 <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-teal-400 to-transparent shadow-[0_4px_20px_rgba(45,212,191,0.5)] animate-[scan_3s_ease-in-out_infinite]" />
               </div>
            </div>

            <div className="text-center lg:text-left flex flex-col justify-center">
              <div className="inline-flex items-center justify-center lg:justify-start gap-2 px-4 py-2 rounded-full bg-teal-50 border border-teal-100 text-teal-700 text-[10px] font-bold uppercase tracking-[0.2em] mb-6 mx-auto lg:mx-0 w-max">
                <div className="w-2 h-2 rounded-full bg-teal-500 animate-pulse" /> AI-Powered Tracking
              </div>
              
              <h2 className="text-4xl md:text-5xl lg:text-7xl font-bold tracking-tighter mb-6 leading-[1.1]">
                Clinical-grade <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-600 to-emerald-400">Skin Analysis.</span>
              </h2>
              
              <p className="text-lg text-gray-500 mb-10 leading-relaxed max-w-lg mx-auto lg:mx-0 font-medium">
                Discover personalized care, identify hidden concerns, and build a tailored routine. Just upload a selfie and get professional insights in seconds.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10 max-w-xl mx-auto lg:mx-0">
                <div className="bg-gray-50 rounded-[1.5rem] p-6 border border-gray-100 transition-all hover:bg-white hover:shadow-xl hover:shadow-teal-500/5 group text-left">
                  <div className="w-10 h-10 rounded-full bg-teal-100 text-teal-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <span className="font-bold">1</span>
                  </div>
                  <h4 className="font-bold text-gray-900 mb-2">Upload Selfie</h4>
                  <p className="text-sm text-gray-500 font-medium leading-relaxed">Take a clear face photo in natural lighting for accurate tracking.</p>
                </div>
                <div className="bg-gray-50 rounded-[1.5rem] p-6 border border-gray-100 transition-all hover:bg-white hover:shadow-xl hover:shadow-teal-500/5 group text-left">
                   <div className="w-10 h-10 rounded-full bg-teal-100 text-teal-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <span className="font-bold">2</span>
                  </div>
                  <h4 className="font-bold text-gray-900 mb-2">AI Scan</h4>
                  <p className="text-sm text-gray-500 font-medium leading-relaxed">Our clinical AI algorithm analyzes 14 sub-dermal markers instantly.</p>
                </div>
              </div>
              
              <Button 
                size="xl" 
                className="w-full sm:w-auto shadow-xl shadow-teal-500/20 hover:shadow-teal-500/30 hover:-translate-y-1 transition-all duration-300 bg-teal-600 hover:bg-teal-700 text-white px-10 py-6 rounded-2xl text-lg font-bold"
                onClick={startAnalysis}
              >
                Scan My Face Now
              </Button>
            </div>

          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-24 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center lg:items-end mb-12 gap-8">
            <div className="max-w-2xl text-center lg:text-left mx-auto lg:mx-0">
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-black mb-4">Honest reviews from our early believers.</h2>
              <p className="text-gray-500 text-base sm:text-lg">Real feedback from users who experienced the Clearvia difference early on.</p>
            </div>
            <div className="flex flex-col items-center lg:items-end gap-4">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-5 h-5 sm:w-6 sm:h-6 fill-teal-500 text-teal-500" />)}
                <span className="ml-4 font-bold text-lg sm:text-xl">4.9/5</span>
              </div>
              <div className="hidden md:flex items-center gap-2">
                <button 
                  onClick={scrollPrev}
                  className="p-3 border border-gray-200 rounded-full hover:bg-black hover:text-white transition-all"
                  aria-label="Previous review"
                >
                  <ChevronRight className="w-5 h-5 rotate-180" />
                </button>
                <button 
                  onClick={scrollNext}
                  className="p-3 border border-gray-200 rounded-full hover:bg-black hover:text-white transition-all"
                  aria-label="Next review"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
          
          <div className="relative -mx-4 sm:mx-0">
            <div 
              ref={carouselRef}
              className="flex gap-4 sm:gap-6 overflow-x-auto snap-x snap-mandatory scrollbar-hide px-4 sm:px-0 pb-8"
              style={{ scrollBehavior: 'smooth', WebkitOverflowScrolling: 'touch' }}
            >
              {reviews.map((review, index) => (
                <div 
                  key={index}
                  className="w-[85vw] sm:min-w-[350px] md:min-w-[400px] p-6 sm:p-8 lg:p-10 bg-gray-50 border border-gray-100 flex-shrink-0 snap-center sm:snap-start transition-all rounded-2xl md:rounded-none"
                >
                  <div className="flex gap-1 mb-4">
                    {[...Array(review.rating)].map((_, i) => <Star key={i} className="w-4 h-4 fill-teal-500 text-teal-500" />)}
                  </div>
                  <p className="text-gray-900 text-sm sm:text-base font-medium mb-8 italic leading-relaxed">"{review.comment}"</p>
                  <div className="flex justify-between items-center text-[10px] sm:text-xs">
                    <span className="font-bold uppercase tracking-wider text-black">{review.name}</span>
                    <span className="text-gray-400">{review.location}</span>
                  </div>
                </div>
              ))}
              {/* Spacer to allow centering last item */}
              <div className="min-w-[7.5vw] sm:hidden flex-shrink-0" />
            </div>
          </div>
          
          <div className="flex justify-center mt-6">
            <div className="flex items-center gap-3 px-4 py-2 bg-gray-50 border border-gray-100 rounded-full">
              <div className="w-2 h-2 bg-teal-500 rounded-full animate-pulse" />
              <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Swipe or use arrows to view more</p>
            </div>
          </div>
        </div>
      </section>

      {/* Key Ingredients Section */}
      <section className="py-24 bg-[#F7FAFA] overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-xs font-bold uppercase tracking-[0.3em] text-teal-600 mb-4">Science Backed</h2>
            <p className="text-3xl md:text-5xl font-bold tracking-tight text-black max-w-2xl mx-auto">
              Potent Ingredients.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 border border-gray-100 rounded-2xl text-center shadow-sm">
              <div className="w-16 h-16 bg-teal-50 text-teal-600 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold">2%</div>
              <h3 className="text-xl font-bold mb-3">Salicylic Acid</h3>
              <p className="text-sm text-gray-500">A BHA that penetrates deep into pores to dissolve dead skin cells, unclogging them and preventing future acne breakouts.</p>
            </div>
            <div className="bg-white p-8 border border-gray-100 rounded-2xl text-center shadow-sm">
              <div className="w-16 h-16 bg-teal-50 text-teal-600 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold">10%</div>
              <h3 className="text-xl font-bold mb-3">Niacinamide</h3>
              <p className="text-sm text-gray-500">Vitamin B3 works to reduce inflammation, minimize pore appearance, and effectively regulate oil production throughout the day.</p>
            </div>
            <div className="bg-white p-8 border border-gray-100 rounded-2xl text-center shadow-sm">
              <div className="w-16 h-16 bg-teal-50 text-teal-600 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold">1%</div>
              <h3 className="text-xl font-bold mb-3">Hyaluronic Acid</h3>
              <p className="text-sm text-gray-500">Attracts and holds moisture in the skin, ensuring deep hydration without feeling heavy or greasy on acne-prone skin.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 7-Day Money Back Guarantee Section */}
      <section className="py-24 bg-gray-50 border-t border-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="w-20 h-20 bg-black text-white rounded-full flex items-center justify-center mx-auto mb-8">
            <ShieldCheck className="w-10 h-10" />
          </div>
          <h2 className="text-3xl md:text-5xl font-bold tracking-tight text-black mb-6">
            7-Day Money Back Guarantee
          </h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            We are so confident in the Clearvia 3-Step Routine that we offer a strict 7-day money-back guarantee. If you don't love it, we'll refund you.*
          </p>
          <details className="text-left text-xs text-gray-400 max-w-3xl mx-auto group">
            <summary className="cursor-pointer list-none text-center font-medium hover:text-gray-600 transition-colors opacity-60">
              *Read full Terms & Conditions
            </summary>
            <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 mt-4 space-y-2 text-gray-500">
              <p className="font-bold uppercase tracking-widest text-black mb-4">Refund Policy Terms & Conditions:</p>
              <p>* To be eligible for a refund, the return request must be initiated within precisely 168 hours (7 days) of delivery.</p>
              <p>* The product must be 100% unused, unopened, and the original anti-tamper holographic seal must remain perfectly intact without any signs of stress.</p>
              <p>* You must provide a continuous, uncut 4K 60fps video recording starting from receiving the package directly from the delivery agent, showing the unboxing, and the product seals.</p>
              <p>* If you claim the product is ineffective, you must submit a certified dermatologist's report (not older than 3 days) stating specifically that our product caused an allergic reaction, along with before and after high-resolution macroscopic clinical images.</p>
              <p>* A ₹499 processing, restocking, and sanitization fee applies to all returns, which will be deducted from your refund.</p>
              <p>* Shipping charges (if applicable) are non-refundable. The customer is responsible for return shipping via premium insured courier.</p>
              <p>* Subject to final approval by our legal and quality assurance team. Processing takes 45-60 business days.</p>
            </div>
          </details>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-[#F7FAFA]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight text-black">
              Frequently Asked Questions
            </h2>
          </div>
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
              <h4 className="font-bold text-lg mb-2">How long does it take to see results?</h4>
              <p className="text-gray-600 text-sm">Most users start seeing a reduction in active acne within 7-10 days. For significant fading of dark spots and overall texture improvement, we recommend consistent use for 4-6 weeks.</p>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
              <h4 className="font-bold text-lg mb-2">Is this suitable for sensitive skin?</h4>
              <p className="text-gray-600 text-sm">Yes! While our ingredients are potent (like 2% Salicylic Acid and 10% Niacinamide), the formulations are balanced with soothing agents like Aloe Vera and Green Tea extract to minimize irritation.</p>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
              <h4 className="font-bold text-lg mb-2">Does the sunscreen leave a white cast?</h4>
              <p className="text-gray-600 text-sm">Not at all. Our Ultra-Matte Sunscreen SPF 50 is specially formulated for Indian skin tones. It blends seamlessly, leaving zero white cast and providing a sweat-resistant matte finish.</p>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
              <h4 className="font-bold text-lg mb-2">Can I use makeup over these products?</h4>
              <p className="text-gray-600 text-sm">Absolutely. The serum and sunscreen are both lightweight and fast-absorbing, making them an excellent primer base for makeup without causing pilling.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Skin Analysis Modal */}
      <AnimatePresence>
        {showAnalysis && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 text-white flex flex-col pt-[5vh] pb-8 px-4 overflow-y-auto"
          >
            <button onClick={closeAnalysis} className="absolute top-6 right-6 p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors z-10">
              <X className="w-6 h-6" />
            </button>

            <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full my-auto py-12">
              {scanStep === 'intro' && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center w-full">
                  <h3 className="text-2xl font-bold mb-2">SkinInsights™ AI</h3>
                  <p className="text-gray-400 text-sm mb-8">Position your face in the center of the frame in good lighting.</p>
                  
                  <div className="relative w-full aspect-[3/4] bg-gray-900 border-2 border-dashed border-gray-700 rounded-3xl overflow-hidden mb-8 flex items-center justify-center">
                     <div className="w-48 h-64 border-2 border-white/20 rounded-[4rem]" />
                     <Camera className="w-12 h-12 text-gray-500 absolute" />
                  </div>

                  <Button size="xl" className="w-full bg-teal-500 hover:bg-teal-600 border-0" onClick={handleCapture}>
                    Capture Photo
                  </Button>
                </motion.div>
              )}

              {scanStep === 'scanning' && (
                <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center w-full">
                  <h3 className="text-xl font-bold mb-8 animate-pulse text-teal-400">Analyzing 14 skin parameters...</h3>
                  
                  <div className="relative w-full aspect-[3/4] rounded-3xl overflow-hidden mb-8 shadow-[0_0_50px_rgba(20,184,166,0.3)]">
                    <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=800" alt="Captured" className="w-full h-full object-cover brightness-75 grayscale-[0.2]" />
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-teal-400 to-transparent shadow-[0_4px_20px_rgba(45,212,191,1)] animate-[scan_2s_ease-in-out_infinite]" />
                    
                    {/* Fake scanning points */}
                    <div className="absolute top-1/3 left-1/3 w-4 h-4 border border-teal-400 rounded-full animate-ping" />
                    <div className="absolute top-1/2 right-1/4 w-3 h-3 border border-orange-400 rounded-full animate-ping" style={{ animationDelay: '0.5s' }} />
                    <div className="absolute bottom-1/3 left-1/2 w-6 h-6 border border-teal-400 rounded-full animate-ping" style={{ animationDelay: '1s' }} />
                  </div>
                </motion.div>
              )}

              {scanStep === 'results' && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full">
                  <div className="flex items-center justify-center gap-2 text-teal-400 mb-6">
                    <CheckCircle className="w-8 h-8" />
                    <h3 className="text-2xl font-bold text-white">Analysis Complete</h3>
                  </div>

                  <div className="bg-gray-900 rounded-3xl p-6 border border-gray-800 mb-8 space-y-6 text-left">
                    <div>
                      <div className="flex justify-between text-sm mb-3"><span className="text-gray-400">Skin Type</span><span className="font-bold text-teal-400 text-right">Oily / Acne Prone</span></div>
                      <div className="flex justify-between text-sm mb-3"><span className="text-gray-400">Hydration Levels</span><span className="font-bold text-white text-right">42% (Low)</span></div>
                      <div className="flex justify-between text-sm"><span className="text-gray-400">Pore Congestion</span><span className="font-bold text-orange-400 text-right">High Risk</span></div>
                    </div>

                    <div className="border-t border-gray-800 pt-6">
                      <p className="text-xs uppercase tracking-widest text-gray-500 font-bold mb-4">AI Recommendation</p>
                      <div className="flex gap-4 items-center bg-black p-4 rounded-2xl border border-gray-800">
                         <img src="https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=200" alt="Routine" className="w-16 h-16 object-cover rounded-xl" />
                         <div>
                           <p className="font-bold text-sm text-white">Clearvia Essential Trio</p>
                           <p className="text-xs text-gray-400 mt-1 line-clamp-2">Matches your profile with 94% efficacy. Targets clogged pores and improves hydration.</p>
                         </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <Button variant="secondary" className="w-full bg-gray-800 hover:bg-gray-700 border-0 text-white" onClick={() => setScanStep('intro')}>
                      <RefreshCw className="w-4 h-4 mr-2" /> Retry
                    </Button>
                    <Button className="w-full bg-teal-500 hover:bg-teal-600 border-0" onClick={() => handleBuyNow('combo')}>
                      Get Your Routine
                    </Button>
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
