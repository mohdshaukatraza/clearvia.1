import { motion } from 'motion/react';
import { BackButton } from '../components/BackButton';

export function Privacy() {
  return (
    <div className="bg-white min-h-screen py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <BackButton />
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16"
        >
          <h1 className="text-4xl sm:text-6xl font-bold tracking-tighter mb-8 italic">Privacy Notice.</h1>
          <p className="text-sm font-bold uppercase tracking-[0.4em] text-teal-600 mb-12">Your data is safe</p>
        </motion.div>

        <div className="space-y-12">
          <section>
            <h2 className="text-xl font-bold text-black mb-4 uppercase tracking-widest">1. Information We Collect</h2>
            <p className="text-gray-500 leading-relaxed mb-4">
              We collect information that you manually provide to us when creating an account, placing an order, or contacting customer support. This includes your name, email address, shipping address, and phone number.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black mb-4 uppercase tracking-widest">2. How We Use Information</h2>
            <p className="text-gray-500 leading-relaxed mb-4">
              Your information is used strictly to fulfill orders, provide customer support, and send important updates regarding your purchases. We occasionally send promotional offers, but you can opt out at any time.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black mb-4 uppercase tracking-widest">3. Data Security</h2>
            <p className="text-gray-500 leading-relaxed mb-4">
              We employ industry-standard security measures to protect your personal information. Payment details are encrypted and securely processed by our payment gateway partners. We do not store your credit card information on our servers.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black mb-4 uppercase tracking-widest">4. Third-Party Services</h2>
            <p className="text-gray-500 leading-relaxed mb-4">
              We may utilize trusted third-party services for analytics, payment processing, and order fulfillment. These parties only have access to information necessary to perform their functions and are obligated to maintain confidentiality.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
