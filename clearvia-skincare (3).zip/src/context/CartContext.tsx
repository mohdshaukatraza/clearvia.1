import React, { createContext, useContext, useState, ReactNode } from 'react';

interface CartItem {
  id: string;
  quantity: number;
}

interface CartContextType {
  cartItemsCount: number;
  items: CartItem[];
  addToCart: (id?: string) => void;
  removeFromCart: (id: string, removeAll?: boolean) => void;
  clearCart: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  const cartItemsCount = items.reduce((sum, item) => sum + item.quantity, 0);

  const addToCart = (id: string = 'combo') => {
    setItems((prev) => {
      const existing = prev.find(item => item.id === id);
      if (existing) {
        return prev.map(item => item.id === id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { id, quantity: 1 }];
    });
  };

  const removeFromCart = (id: string, removeAll: boolean = false) => {
    setItems((prev) => {
      if (removeAll) {
        return prev.filter((item) => item.id !== id);
      }
      
      const existing = prev.find(item => item.id === id);
      if (existing && existing.quantity > 1) {
        return prev.map(item => item.id === id ? { ...item, quantity: item.quantity - 1 } : item);
      }
      return prev.filter((item) => item.id !== id);
    });
  };

  const clearCart = () => {
    setItems([]);
  };

  return (
    <CartContext.Provider value={{ cartItemsCount, items, addToCart, removeFromCart, clearCart }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
