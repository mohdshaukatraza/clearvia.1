export const productsListData = [
  {
    id: 'combo',
    name: 'Essential Trio: Acne & Oil Control Combo',
    subtitle: 'The Complete Routine',
    price: 999,
    originalPrice: 1499,
    tag: 'Best Value',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'facewash',
    name: 'Deep Cleansing Face Wash',
    subtitle: 'Step 1: Cleanse',
    price: 349,
    originalPrice: 499,
    tag: 'New',
    image: 'https://images.unsplash.com/photo-1611078489935-0cb964de46d6?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'serum',
    name: 'Acne-Defense Serum',
    subtitle: 'Step 2: Treat',
    price: 499,
    originalPrice: 699,
    tag: 'Potent Formula',
    image: 'https://images.unsplash.com/photo-1629198688000-71f23e745b6e?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'sunscreen',
    name: 'Ultra-Matte Sunscreen SPF 50',
    subtitle: 'Step 3: Protect',
    price: 399,
    originalPrice: 599,
    tag: 'No White Cast',
    image: 'https://images.unsplash.com/photo-1526947425960-945c6e72858f?auto=format&fit=crop&q=80&w=800',
  }
];

export const productsData: Record<string, any> = {
  combo: {
    id: 'combo',
    name: 'Essential Trio: Acne & Oil Control Combo',
    price: 999,
    originalPrice: 1499,
    discount: 'Save 33%',
    description: 'Your daily 3-step routine for clear, matte, and glowing skin. Includes Deep Cleansing Face Wash (100ml), Acne-Defense Serum (30ml), and Ultra-Matte Sunscreen (50ml).',
    images: [
      "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1599305090598-fe179d501227?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&q=80&w=800"
    ],
    benefits: [
      "Helps clear active acne and reduces the appearance of new breakouts.",
      "Helps control sebum production to keep skin matte all day.",
      "Assists in fading dark spots and hyperpigmentation.",
      "Protects from UVA/UVB rays with SPF 50.",
      "Soothes inflammation and redness."
    ],
    ingredients: [
      { name: "Salicylic Acid", desc: "Unclogs pores and minimizes oil." },
      { name: "Niacinamide", desc: "Improves skin texture and tone." },
      { name: "Vitamin C", desc: "Brightens skin and fights radicals." }
    ],
    otherIngredients: "Aqua, Aloe Barbadensis Leaf Extract, Glycerin, Witch Hazel Extract, Hyaluronic Acid, Tocopheryl Acetate, Zinc Oxide, Titanium Dioxide, Green Tea Extract, Phenoxyethanol.",
    howToUse: [
      "Cleanse your face using the Face Wash. Pat dry softly with a clean towel.",
      "Apply 2-3 drops of Serum on your face and neck. Gently dab until absorbed.",
      "Follow up with the Sunscreen before stepping out or as the last step of your routine."
    ],
    freeShipping: true
  },
  facewash: {
    id: 'facewash',
    name: 'Deep Cleansing Face Wash',
    price: 349,
    originalPrice: 499,
    discount: '5% Off',
    description: 'A gentle yet effective daily cleanser designed to remove excess oil and impurities without stripping your skin of moisture. Formulated specifically for Indian skin types.',
    images: [
      "https://images.unsplash.com/photo-1611078489935-0cb964de46d6?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&q=80&w=800"
    ],
    benefits: [
      "Deeply cleanses pores and removes stubborn dirt and makeup residue.",
      "Maintains the skin's natural moisture barrier and pH level.",
      "Helps reduce excess oil production and sebum.",
      "Leaves skin feeling fresh, supple, and perfectly prepped."
    ],
    ingredients: [
      { name: "Salicylic Acid (BHA)", desc: "A beta hydroxy acid that gently exfoliates and penetrates deep inside pores to dissolve dead skin cells and prevent acne." },
      { name: "Neem & Tea Tree Extract", desc: "Powerhouse botanical ingredients with natural antibacterial properties to fight persistent acne and soothe inflammation." },
      { name: "Aloe Vera", desc: "Provides instantly calming hydration and prevents the tight, dry feeling after washing." }
    ],
    otherIngredients: "Aqua, Sodium Laureth Sulfate, Cocamidopropyl Betaine, Glycerin, PEG-7 Glyceryl Cocoate, Fragrance, Phenoxyethanol.",
    howToUse: [
      "Splash your face with lukewarm water to open up your pores.",
      "Squeeze a coin-sized amount of face wash onto your wet palms and lather.",
      "Gently massage onto your face and neck in circular motions for at least 60 seconds. Pay extra attention to your T-zone.",
      "Rinse thoroughly and pat dry with a clean, soft towel."
    ],
    freeShipping: false
  },
  serum: {
    id: 'serum',
    name: 'Acne-Defense Serum',
    price: 499,
    originalPrice: 699,
    discount: '5% Extra Off',
    description: 'A concentrated, fast-absorbing serum that targets active breakouts and fades old acne scars. Delivers potent actives deep into the skin.',
    images: [
      "https://images.unsplash.com/photo-1629198688000-71f23e745b6e?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=800"
    ],
    benefits: [
      "Helps reduce the size, redness, and appearance of active pimples.",
      "Assists in fading post-acne marks (hyperpigmentation) and dark spots.",
      "Improves overall skin texture and promotes a smoother surface.",
      "100% Non-comedogenic and fast-absorbing lightweight texture."
    ],
    ingredients: [
      { name: "Niacinamide (5%)", desc: "Vitamin B3 derivative that strengthens the skin barrier, reduces inflammation, and regulates oil production while fading dark spots." },
      { name: "Zinc PCA", desc: "A synergy of zinc and L-PCA that controls sebum generation and significantly reduces redness and irritation." },
      { name: "Hyaluronic Acid", desc: "Provides deep lightweight hydration without clogging pores, keeping skin plump and healthy." }
    ],
    otherIngredients: "Aqua, Propanediol, Glycerin, Sodium Hyaluronate, Xanthan Gum, Phenoxyethanol, Ethylhexylglycerin.",
    howToUse: [
      "Start with a freshly cleansed and slightly damp face.",
      "Apply 2-3 drops of the serum to your entire face using the dropper.",
      "Gently press and pat the serum into your skin using your fingertips. Do not rub vigorously.",
      "Wait for 1-2 minutes to allow full absorption before applying your sunscreen or moisturizer."
    ],
    freeShipping: false
  },
  sunscreen: {
    id: 'sunscreen',
    name: 'Ultra-Matte Sunscreen SPF 50',
    price: 399,
    originalPrice: 599,
    discount: 'Extra 5% Off',
    description: 'A broad-spectrum, zero white cast sunscreen that provides a long-lasting matte finish. Perfect for daily wear even in humid conditions.',
    images: [
      "https://images.unsplash.com/photo-1526947425960-945c6e72858f?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&q=80&w=800"
    ],
    benefits: [
      "SPF 50 PA+++ provides complete UVA and UVB protection.",
      "Leaves zero white cast on Indian skin tones.",
      "Helps keep skin matte and shine-free all day.",
      "Sweat and water-resistant formulation for up to 80 minutes of activity."
    ],
    ingredients: [
      { name: "Zinc Oxide (Micronized)", desc: "A safe physical UV filter that forms a protective shield on top of the skin without leaving a chalky residue." },
      { name: "Titanium Dioxide", desc: "Works with Zinc to reflect and scatter harmful UVA/UVB rays instantly upon application." },
      { name: "Vitamin E", desc: "A potent antioxidant that protects skin from environmental damage and free radicals." }
    ],
    otherIngredients: "Aqua, Cyclopentasiloxane, Dimethicone Crosspolymer, Glycerin, Polyacrylamide, C13-14 Isoparaffin, Laureth-7, Phenoxyethanol.",
    howToUse: [
      "Complete your morning skincare routine (Cleanser -> Serum).",
      "Squeeze out a generous amount equal to the length of two fingers.",
      "Dot it evenly across your face, neck, and exposed areas.",
      "Massage gently in one direction until it blends completely into a seamless matte finish.",
      "Reapply every 3-4 hours if you are continuously outdoors or directly exposed to the sun."
    ],
    freeShipping: false
  }
};
