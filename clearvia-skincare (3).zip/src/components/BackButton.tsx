import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function BackButton() {
  const navigate = useNavigate();
  return (
    <button 
      onClick={() => navigate(-1)} 
      className="flex items-center gap-2 text-gray-400 hover:text-black transition-colors mb-8 text-xs font-bold uppercase tracking-widest"
    >
      <ArrowLeft className="w-4 h-4" />
      Back
    </button>
  );
}
