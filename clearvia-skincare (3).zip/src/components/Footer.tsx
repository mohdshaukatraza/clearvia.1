import { Link } from 'react-router-dom';
import { Instagram, MessageCircle, Phone } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200 pt-20 pb-10">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 mb-16">
          <div className="md:col-span-5">
            <Link to="/" className="text-[28px] font-bold tracking-tight text-[#1A1A1A] font-sans mb-6 block">
              Clearvia
            </Link>
            <p className="text-gray-500 max-w-sm mb-6 leading-relaxed text-sm font-medium">
              We make potent, transparent, and clinically-effective skincare for Indian skin.
            </p>
            <form className="flex border-b border-gray-300 w-full max-w-sm pb-2 mt-8">
              <input type="email" placeholder="Enter your email for updates" className="w-full outline-none text-sm placeholder-gray-400" />
              <button className="text-xs font-bold uppercase tracking-widest text-[#1A1A1A] hover:text-gray-500">Subscribe</button>
            </form>
          </div>

          <div className="md:col-span-2 md:col-start-7">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gray-900 mb-6">Shop</h4>
            <ul className="space-y-4">
              <li><Link to="/product/combo" className="text-gray-500 hover:text-black transition-colors text-sm">Essential Trio</Link></li>
              <li><Link to="/product/facewash" className="text-gray-500 hover:text-black transition-colors text-sm">Face Wash</Link></li>
              <li><Link to="/product/serum" className="text-gray-500 hover:text-black transition-colors text-sm">Serum</Link></li>
              <li><Link to="/product/sunscreen" className="text-gray-500 hover:text-black transition-colors text-sm">Sunscreen</Link></li>
            </ul>
          </div>

          <div className="md:col-span-2">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gray-900 mb-6">Help</h4>
            <ul className="space-y-4">
              <li><Link to="/track-order" className="text-gray-500 hover:text-black transition-colors text-sm">Track Order</Link></li>
              <li><Link to="/faq" className="text-gray-500 hover:text-black transition-colors text-sm">FAQs</Link></li>
              <li><Link to="/shipping-policy" className="text-gray-500 hover:text-black transition-colors text-sm">Shipping & Delivery</Link></li>
              <li><Link to="/refund-policy" className="text-gray-500 hover:text-black transition-colors text-sm">Returns</Link></li>
            </ul>
          </div>

          <div className="md:col-span-2">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gray-900 mb-6">Connect</h4>
            <ul className="space-y-4">
              <li>
                <a href="https://www.instagram.com/clearvia.in" target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-black transition-colors text-sm">Instagram</a>
              </li>
              <li>
                <a href="https://wa.me/message/3MPLW7S7QCJWC1" target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-black transition-colors text-sm">WhatsApp</a>
              </li>
              <li>
                <a href="mailto:hello@clearvia.in" className="text-gray-500 hover:text-black transition-colors text-sm">Email Us</a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-100 pt-8 flex flex-col md:flex-row justify-between items-center text-[11px] text-gray-400 font-medium tracking-wide">
          <div className="flex flex-col items-start space-y-2 mb-4 md:mb-0">
            <p>© {new Date().getFullYear()} Clearvia Skincare.</p>
            <p className="max-w-2xl text-[10px] text-gray-400/80 leading-relaxed uppercase">
              Disclaimer: The information and products on this website are for general informational purposes only and are not intended to diagnose, treat, cure, or prevent any disease. Please consult with a dermatologist or healthcare professional before beginning any new skincare regimen.
            </p>
          </div>
          <div className="flex space-x-6 shrink-0">
            <Link to="/privacy" className="hover:text-black transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-black transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
