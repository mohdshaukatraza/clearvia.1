import { Link } from 'react-router-dom';
import { ShoppingBag, Menu, X, Search } from 'lucide-react';
import { useState } from 'react';
import { useCart } from '../context/CartContext';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { cartItemsCount } = useCart();

  const navLinks = [
    { name: 'Shop', path: '/shop' },
    { name: 'Get Clear Skin', path: '/clear-skin' },
    { name: 'Track Order', path: '/track-order' },
    { name: 'About', path: '/about' },
    { name: 'FAQ', path: '/faq' },
  ];

  return (
    <>
      <div className="bg-[#1C1C1C] text-[#F3F3F3] text-xs font-medium text-center py-2 px-4 tracking-wide relative z-50">
        Get 5% off on your first order. Use code: <span className="font-bold">WELCOME05</span>
      </div>
      <nav className="sticky top-0 left-0 right-0 z-40 bg-white border-b border-gray-100 transition-all">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 xl:px-8">
          <div className="flex justify-between items-center h-[72px]">
            {/* Mobile Menu Button (Left) */}
            <div className="md:hidden flex items-center">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="p-2 -ml-2 text-gray-800 hover:text-black focus:outline-none"
              >
                {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>

            {/* Logo (Center on mobile, Left on desktop) */}
            <div className="flex-1 md:flex-none flex justify-center md:justify-start items-center">
              <Link to="/" className="text-[28px] font-bold tracking-tight text-[#1A1A1A] font-sans">
                Clearvia
              </Link>
            </div>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center space-x-8 ml-8 flex-1">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className="text-[14px] font-medium text-gray-700 hover:text-black transition-colors"
                >
                  {link.name}
                </Link>
              ))}
            </div>

            {/* Right Icons */}
            <div className="flex items-center space-x-4 md:space-x-6">
              <button className="hidden md:block text-gray-700 hover:text-black">
                <Search className="w-[18px] h-[18px]" />
              </button>
              <Link to="/checkout" className="relative text-gray-700 hover:text-black transition-colors flex items-center justify-center">
                <ShoppingBag className="w-5 h-5" />
                {cartItemsCount > 0 && (
                  <span className="absolute -top-1.5 -right-2 flex items-center justify-center w-4 h-4 text-[10px] font-bold text-white bg-[#1A1A1A] rounded-full border border-white">
                    {cartItemsCount}
                  </span>
                )}
              </Link>
            </div>
          </div>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-b border-gray-100 overflow-hidden"
            >
              <div className="px-4 pt-2 pb-6 space-y-1">
                {navLinks.map((link) => (
                  <Link
                    key={link.name}
                    to={link.path}
                    onClick={() => setIsOpen(false)}
                    className="block px-3 py-4 text-base font-medium text-gray-900 border-b border-gray-50 last:border-0"
                  >
                    {link.name}
                  </Link>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </>
  );
}
