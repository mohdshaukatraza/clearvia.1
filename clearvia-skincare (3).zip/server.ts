import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { productsListData } from './src/data/products.ts';

let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  app.post('/api/chat', async (req, res) => {
    try {
      if (!ai) {
         return res.json({ text: "I'm sorry, I'm currently unavailable as my API key is not configured. Please add GEMINI_API_KEY to your environment variables." });
      }

      const { message, chatHistory } = req.body;
      
      const systemInstruction = `You are a professional skincare expert working for our brand. 
You can understand and communicate fluently in English, written Hindi, and Roman Hindi (Hinglish). Adjust your language to match the user's input language.

Your goal is to answer skincare-related questions and ONLY suggest products from our catalog. 
If someone asks about something completely unrelated to skin, politely redirect them to skincare.

Our Product Catalog:
${productsListData.map(p => `- ${p.name} ($${p.price}): ${p.subtitle}`).join('\n')}

Keep your answers concise, helpful, and professional. Use formatting (bullet points, bold text) where appropriate. Give clear skincare advice based on common skin knowledge.`;

      const formattedHistory = chatHistory ? chatHistory.map((msg: any) => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: msg.parts // Pass parts directly to allow inlineData (images)
      })) : [];

      const userParts: any[] = message ? [{ text: message }] : [];
      if (req.body.image) {
         userParts.push({
           inlineData: {
             data: req.body.image.data,
             mimeType: req.body.image.mimeType
           }
         });
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
          { role: 'user', parts: [{ text: systemInstruction }] },
          { role: 'model', parts: [{ text: 'Understood. I will be a helpful skincare expert and only recommend your products.' }] },
          ...formattedHistory,
          { role: 'user', parts: userParts }
        ],
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Chat error:", error);
      res.status(500).json({ error: "Sorry, I'm experiencing technical difficulties." });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
